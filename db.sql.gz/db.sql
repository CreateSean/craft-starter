-- MySQL dump 10.13  Distrib 5.7.32, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	5.7.32-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text COLLATE utf8_unicode_ci,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kazakzgmtsfjroaaxgyhmwcthtkqadhwsiqr` (`sessionId`,`volumeId`),
  KEY `idx_lixkmyosbqnxcneeubsgabfwjiazxsjjohtq` (`volumeId`),
  CONSTRAINT `fk_lmtnmgytesobitpjthsqpldpfqakzuemiopq` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kind` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fwysriaxrlxamvgjmjyoeixwdzqsfrmulyvz` (`filename`,`folderId`),
  KEY `idx_svpvdmmrmxnknprzmpzidotsnpxwxnqavytt` (`folderId`),
  KEY `idx_hyccxuuiopzqowpbwfwwemtmllmhezspdxjv` (`volumeId`),
  KEY `fk_liqsamitsnlufkrxcysyjzcvoiwqcmuzstau` (`uploaderId`),
  CONSTRAINT `fk_ackeozzzxsujlowtqnzpmalkutlmvbaaytlb` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_liqsamitsnlufkrxcysyjzcvoiwqcmuzstau` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mgeunffhwvrmaaylgixnwnjyzqaatrruqtat` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mlfuttxtpisijtuxbenrcwfqhoblzdslszzx` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assettransformindex`
--

DROP TABLE IF EXISTS `assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ehwreiggwjloaafgfopincbtywyqtybxiewm` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assettransformindex`
--

LOCK TABLES `assettransformindex` WRITE;
/*!40000 ALTER TABLE `assettransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `assettransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assettransforms`
--

DROP TABLE IF EXISTS `assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ihiwmjyiropgrcqvewasspifjcsdgthbaqal` (`name`),
  KEY `idx_kcyfmpvibcewfzzeilrdvmbmptfhjnxbgiil` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assettransforms`
--

LOCK TABLES `assettransforms` WRITE;
/*!40000 ALTER TABLE `assettransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `assettransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lvynzexdtsefirhzrjsnwceklrduwuurciio` (`groupId`),
  KEY `fk_kctispfwnxruxxqqitufguekfbjqxriokudn` (`parentId`),
  CONSTRAINT `fk_atyhapqfsqxhojfpwvyfezexvgjrzwuyyjey` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kctispfwnxruxxqqitufguekfbjqxriokudn` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vajpqyhugljpcrasyquzogvckpuzorkxngdh` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gukhqtezeedczxvfzugswluctdcnnenppbor` (`name`),
  KEY `idx_xhdcufkfwcrccxybxqqhbxgjfymbcxkborau` (`handle`),
  KEY `idx_pywlctpibyhqcbcjqcmppvnehiolsammfzre` (`structureId`),
  KEY `idx_liusrgwpjdfqtfxodyaehrcjkgkiwmbhqjkg` (`fieldLayoutId`),
  KEY `idx_nfvmfhxrpsakqimwdrooqcumwfvvoogiuowb` (`dateDeleted`),
  CONSTRAINT `fk_sdegdxocwmzkllpucjijwqkbrdwmldhnckgk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sszhjifzkfsksohmudlbmfnzzesohhxbflzv` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8_unicode_ci,
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mtdobtnfqeraykxymknmgfyvllcilqqxwocj` (`groupId`,`siteId`),
  KEY `idx_pxmwgqeilfytssonbmopmmwzcxxdgkyuligy` (`siteId`),
  CONSTRAINT `fk_fhoqzfecrwfzaaibrzkjjmlrxatocgatsxoe` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_frdbysgegpqgfpmfhaotrsuodasahhcsewtb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_afrmpvghxkgqivoycjnnsqrpnckvwpvdfhus` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_lmqhdhbcchwmyxioiezcqdhbnbfgfrsplpoc` (`siteId`),
  KEY `fk_bqlttdgxuurbdrbicqskhmfdwaegvqnpmjvz` (`userId`),
  CONSTRAINT `fk_bqlttdgxuurbdrbicqskhmfdwaegvqnpmjvz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_lmqhdhbcchwmyxioiezcqdhbnbfgfrsplpoc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zyzqqcotxifktlxjgjmmtmyoyotccuwgxgdy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_gjqqvjoexhvxwklknlmiyeqylioegkqdhagi` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ieusrpziaiciwonqplhqmvunlrbgwcgndplw` (`siteId`),
  KEY `fk_eqocsncvoklvbfwkoihhxheqkbrkcdetbjgx` (`fieldId`),
  KEY `fk_fvimxcrecsxdpifdghqttlhvtnkyzmlpfhlq` (`userId`),
  CONSTRAINT `fk_eqocsncvoklvbfwkoihhxheqkbrkcdetbjgx` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_flurnradqcsqkfonlkfzavxitcgtpljxlbyf` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fvimxcrecsxdpifdghqttlhvtnkyzmlpfhlq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ieusrpziaiciwonqplhqmvunlrbgwcgndplw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (9,2,2,'2021-02-06 19:47:31',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `field_seo` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hoidunhlkqkxjxqdwarkllmqpnxqgpmyfiho` (`elementId`,`siteId`),
  KEY `idx_ekdqylvuwfdgisrrymqodratierhoccaxnob` (`siteId`),
  KEY `idx_bjjrajrdlijghktwrpqjslxxyplvveyfozoz` (`title`),
  CONSTRAINT `fk_eckttpiljzxjbfihzdcbkpmgdhkmgmggqkng` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ltgcipkkyhqcluzfnsoquemhzfvvhrfecgit` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,2,NULL,'2021-02-06 19:29:01','2021-02-06 19:29:01','2a9b7937-99a7-45f2-a29c-42be2ff26f03',NULL),(2,2,2,'Homepage','2021-02-06 19:41:10','2021-02-06 19:41:18','a0377d4a-110f-4e47-b077-af9f270b2493',NULL),(3,3,2,'Homepage','2021-02-06 19:41:10','2021-02-06 19:41:10','10c81645-07d0-4059-9769-23794aab99f3',NULL),(4,4,2,'Homepage','2021-02-06 19:41:18','2021-02-06 19:41:18','0b7c170a-e5a9-44c9-815d-83233d467059','{\"bundleVersion\":\"1.0.22\",\"sourceBundleType\":\"field\",\"sourceId\":null,\"sourceName\":null,\"sourceHandle\":null,\"sourceType\":\"field\",\"typeId\":null,\"sourceTemplate\":\"\",\"sourceSiteId\":null,\"sourceAltSiteSettings\":[],\"sourceDateUpdated\":\"2021-02-06T14:41:18-05:00\",\"metaGlobalVars\":{\"language\":null,\"mainEntityOfPage\":\"\",\"seoTitle\":\"\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"\",\"robots\":\"\",\"ogType\":\"\",\"ogTitle\":\"\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"\",\"ogImage\":\"\",\"ogImageWidth\":\"\",\"ogImageHeight\":\"\",\"ogImageDescription\":\"\",\"twitterCard\":\"\",\"twitterCreator\":\"\",\"twitterTitle\":\"\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"\",\"twitterImage\":\"\",\"twitterImageWidth\":\"\",\"twitterImageHeight\":\"\",\"twitterImageDescription\":\"\"},\"metaSiteVars\":{\"siteName\":\"\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]},\"metaSitemapVars\":{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[],\"sitemapVideoFieldMap\":[]},\"metaContainers\":{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}},\"redirectsContainer\":[],\"frontendTemplatesContainer\":{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false},\"metaBundleSettings\":{\"siteType\":\"\",\"siteSubType\":\"\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}}'),(6,9,2,'General','2021-02-06 19:42:26','2021-02-06 19:47:31','ddc58e65-d910-48a4-996e-18e9cf14f137',NULL),(7,11,2,'General','2021-02-06 19:42:27','2021-02-06 19:42:27','f4e524d8-1d3e-4d13-8bbd-3c164ebbfe0e',NULL),(8,13,2,'General','2021-02-06 19:42:53','2021-02-06 19:42:53','7f82dadb-8f6a-4cc0-811e-2c389ee690c7',NULL),(9,15,2,'General','2021-02-06 19:45:15','2021-02-06 19:45:15','98fc37ae-0074-4ab3-9dd8-5af92ba0f99f',NULL),(10,17,2,'General','2021-02-06 19:45:18','2021-02-06 19:45:18','be82c887-44e6-4738-b002-3a053cd04981',NULL),(11,19,2,'General','2021-02-06 19:47:31','2021-02-06 19:47:31','e75daba3-7530-4e16-8134-2d8ad2b19681',NULL),(13,21,2,'General','2021-02-06 19:48:37','2021-02-06 19:48:37','f09084ef-bab3-432a-90ac-fa78dbf3ad71',NULL),(14,22,2,'General','2021-02-06 19:48:37','2021-02-06 19:48:37','a2fdcaa2-ddf6-4b77-9ea8-2f9ec750630b',NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_keqddhecjkbvkbijtmhhagpkvympxcoungsd` (`userId`),
  CONSTRAINT `fk_keqddhecjkbvkbijtmhhagpkvympxcoungsd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `traces` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usloplyjoqknmafygkwvngpgfofmwpsotxso` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_mcaielezipenjnhnvvfxfcunczifbzfgpzwa` (`creatorId`),
  KEY `fk_udiutesqzelicutijbdppmffxdhmfyhywoos` (`sourceId`),
  CONSTRAINT `fk_mcaielezipenjnhnvvfxfcunczifbzfgpzwa` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_udiutesqzelicutijbdppmffxdhmfyhywoos` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementindexsettings`
--

DROP TABLE IF EXISTS `elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tlzumccrlmxecvncmkvigvmwdehmjwchqrbw` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementindexsettings`
--

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zfodoaxijsdtpbwmphuodoldfiurdkagtcif` (`dateDeleted`),
  KEY `idx_mngdhyexnfsdoerpgqothpnuvqamtqykrprd` (`fieldLayoutId`),
  KEY `idx_irxbhabqjzhvdyuhxnzwgnycwvdpkmggqkhd` (`type`),
  KEY `idx_cujubggjxlvcqqoprygejbbctexnocoxjlsl` (`enabled`),
  KEY `idx_xdncyfkbtwromohsbuhimiuokvedmsvymkpl` (`archived`,`dateCreated`),
  KEY `idx_byidjdltajhfcrhorjjfcwkwvautkbxthdmt` (`archived`,`dateDeleted`,`draftId`,`revisionId`),
  KEY `fk_fnmzxesfgtjcojojedeogknrcnpnkwmsxacf` (`draftId`),
  KEY `fk_wfwopfvvmoojmcoztjykdkfiubwuvhiscgre` (`revisionId`),
  CONSTRAINT `fk_atpdtwukxmimrropmbaketqmyvcnhuboydzd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fnmzxesfgtjcojojedeogknrcnpnkwmsxacf` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wfwopfvvmoojmcoztjykdkfiubwuvhiscgre` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2021-02-06 19:29:01','2021-02-06 19:29:01',NULL,'89cbdc5d-4bdb-48c1-bb5a-7e05bb10b480'),(2,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2021-02-06 19:41:10','2021-02-06 19:41:18',NULL,'2f8cd90f-3245-4574-b88a-d7ad8a83e6b7'),(3,NULL,1,7,'craft\\elements\\Entry',1,0,'2021-02-06 19:41:10','2021-02-06 19:41:10',NULL,'23b8e354-5f38-4258-a1fb-50358b0b0803'),(4,NULL,2,7,'craft\\elements\\Entry',1,0,'2021-02-06 19:41:18','2021-02-06 19:41:18',NULL,'c369ca80-58ee-4251-bc88-2dd963e06f00'),(6,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2021-02-06 19:42:15','2021-02-06 19:42:15','2021-02-06 19:42:18','c4094200-949e-4b9e-8697-c59aa2663432'),(7,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2021-02-06 19:42:18','2021-02-06 19:42:18','2021-02-06 19:42:22','2a342903-93e8-4406-a337-fd4ad8f496db'),(9,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2021-02-06 19:42:26','2021-02-06 19:47:31','2021-02-06 19:47:44','b2335b18-454b-4d1b-a7e7-a171e0848bea'),(10,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2021-02-06 19:42:26','2021-02-06 19:45:18','2021-02-06 19:47:31','3d4ef9da-ae5a-4ab3-802c-438f83b81c9a'),(11,NULL,3,8,'craft\\elements\\Entry',1,0,'2021-02-06 19:42:26','2021-02-06 19:42:26','2021-02-06 19:47:44','e79ec66e-41b2-43ca-bad7-0015a1fd472a'),(12,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2021-02-06 19:42:27','2021-02-06 19:42:22',NULL,'f0f973da-8293-4277-b374-b2d2709a0f63'),(13,NULL,4,8,'craft\\elements\\Entry',1,0,'2021-02-06 19:42:53','2021-02-06 19:42:53','2021-02-06 19:47:44','56e40cba-aaac-4ea1-9297-ec1df2a5dccf'),(14,NULL,NULL,2,'craft\\elements\\MatrixBlock',0,0,'2021-02-06 19:42:53','2021-02-06 19:42:53',NULL,'c9904521-9514-4548-9a10-3150c837e0ca'),(15,NULL,5,8,'craft\\elements\\Entry',1,0,'2021-02-06 19:45:15','2021-02-06 19:45:15','2021-02-06 19:47:44','458fc8c6-064e-4055-84c1-d1b8098e1ac9'),(16,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2021-02-06 19:45:15','2021-02-06 19:45:15',NULL,'b81e4f0f-c57d-4734-af5d-0c1045dbeced'),(17,NULL,6,8,'craft\\elements\\Entry',1,0,'2021-02-06 19:45:18','2021-02-06 19:45:18','2021-02-06 19:47:44','dae98b09-eb0b-4460-afb9-c078e0ea8d14'),(18,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2021-02-06 19:45:18','2021-02-06 19:45:18',NULL,'c1114ab3-7017-4cda-a66d-cea912cfb54b'),(19,NULL,7,8,'craft\\elements\\Entry',1,0,'2021-02-06 19:47:31','2021-02-06 19:47:31','2021-02-06 19:47:44','cfe36b39-6cf7-4f5c-a2cc-7456dc85cab3'),(21,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2021-02-06 19:48:37','2021-02-06 19:48:37',NULL,'3668a2ee-3c6f-4d4f-8886-e9f44e96cabc'),(22,NULL,8,9,'craft\\elements\\Entry',1,0,'2021-02-06 19:48:37','2021-02-06 19:48:37',NULL,'4a940be5-95a2-4dfa-be8a-09d62680347e');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mmvqhxkxosjipkwaosubkjxnnrndomrkewgr` (`elementId`,`siteId`),
  KEY `idx_wfgynfqhrgfoaqbxbfftcehiwnsdgoiukcch` (`siteId`),
  KEY `idx_cmcbpvxiqeuxpokrnvfcxqmeblilaggczvjc` (`slug`,`siteId`),
  KEY `idx_evyqgiwclfhdmgzoumbxntgcbwlvhnmfbhrn` (`enabled`),
  KEY `idx_slonrvoejuskuqlodovudrtdiwjhfxweojem` (`uri`,`siteId`),
  CONSTRAINT `fk_mpdtdaojbobfdipipiqiylvbtpnpgjmxalyp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oohkbfzfmwdlfieomvrffbflwdzcovdyfojb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,2,NULL,NULL,1,'2021-02-06 19:29:01','2021-02-06 19:29:01','1d03f731-3571-4598-9883-2dcd001eb123'),(2,2,2,'homepage','homepage',1,'2021-02-06 19:41:10','2021-02-06 19:41:10','df80cb5f-8c9d-4545-846d-c193443f7b58'),(3,3,2,'homepage','homepage',1,'2021-02-06 19:41:10','2021-02-06 19:41:10','65560a5b-2677-4ae0-afa1-020cbca5e7c8'),(4,4,2,'homepage','homepage',1,'2021-02-06 19:41:18','2021-02-06 19:41:18','49cfd78f-1835-4efc-9636-cf035d0f52ce'),(6,6,2,NULL,NULL,1,'2021-02-06 19:42:15','2021-02-06 19:42:15','f6483d8a-59ec-47d9-aea5-34946b5c0895'),(7,7,2,NULL,NULL,1,'2021-02-06 19:42:18','2021-02-06 19:42:18','dc05fead-790f-47ac-bb2d-deed052280c6'),(9,9,2,'general','user-guide/general',1,'2021-02-06 19:42:26','2021-02-06 19:42:27','78536a8f-be22-4856-bbde-2c8cd424a85f'),(10,10,2,NULL,NULL,1,'2021-02-06 19:42:26','2021-02-06 19:42:26','fbf0782c-5e7d-4c88-8e48-c45a75a1328c'),(11,11,2,'general','user-guide/general',1,'2021-02-06 19:42:27','2021-02-06 19:42:27','d751f6f3-eb63-4804-bd0d-2eb644e48ade'),(12,12,2,NULL,NULL,1,'2021-02-06 19:42:27','2021-02-06 19:42:27','89d62d4c-ac05-4212-84ee-68ed4bce71fd'),(13,13,2,'general','user-guide/general',1,'2021-02-06 19:42:53','2021-02-06 19:42:53','a277c0b9-2b2f-42ec-9c95-64427203c4fd'),(14,14,2,NULL,NULL,1,'2021-02-06 19:42:53','2021-02-06 19:42:53','da6ee6ef-f9c0-46b1-a69c-46fe088e4213'),(15,15,2,'general','user-guide/general',1,'2021-02-06 19:45:15','2021-02-06 19:45:15','0805933f-5db0-4bf3-825b-aa98997a371b'),(16,16,2,NULL,NULL,1,'2021-02-06 19:45:15','2021-02-06 19:45:15','ceb98223-b442-4020-a87d-943ba5bea9eb'),(17,17,2,'general','user-guide/general',1,'2021-02-06 19:45:18','2021-02-06 19:45:18','c96aa76c-b75c-4e38-8d71-659fa7eba517'),(18,18,2,NULL,NULL,1,'2021-02-06 19:45:18','2021-02-06 19:45:18','35029ad3-4692-4c99-afc1-979b539792f1'),(19,19,2,'general','user-guide/general',1,'2021-02-06 19:47:31','2021-02-06 19:47:31','b6be566f-c10b-4c92-8783-54d1c4688530'),(21,21,2,'general','user-guide/general',1,'2021-02-06 19:48:37','2021-02-06 19:48:37','a1e4dd8e-509b-4618-89d4-9551bfa9c1f9'),(22,22,2,'general','user-guide/general',1,'2021-02-06 19:48:37','2021-02-06 19:48:37','727dc272-cf3e-47ec-8968-2850cc853e6a');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ibdmgimgkdjvyixacwdotcyeifhhtkljopnm` (`postDate`),
  KEY `idx_aswhceanxibluoqgnckozgmwqfostggzeqde` (`expiryDate`),
  KEY `idx_lsgfpvvphjvcmszqjbscbnnohnuxergabhsn` (`authorId`),
  KEY `idx_bhtuopumjemhztrhpmsdgslcruddmxpfhetg` (`sectionId`),
  KEY `idx_zbzsmmqkefdbtdnnvwzqjjsylbkwehuryrfy` (`typeId`),
  KEY `fk_xmopemjunvbcqgfxrqnlmjszsyuhnnxghals` (`parentId`),
  CONSTRAINT `fk_mjgeicimqequvybiadlgukmnzxsndtdgxkrt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oyfzdeevyqkjeuiabmwqwvowthoynvwzpkeh` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qahrcitbaqqyihjdhzpdwdeisttwjmsanzzu` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xmopemjunvbcqgfxrqnlmjszsyuhnnxghals` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xmubhljtoqztxdbfzdwmarxbykvzrxqtllbr` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,1,NULL,'2021-02-06 19:41:00',NULL,NULL,'2021-02-06 19:41:10','2021-02-06 19:41:10','baf75d86-ff1c-4f74-a8b7-60342fa83477'),(3,1,NULL,1,NULL,'2021-02-06 19:41:00',NULL,NULL,'2021-02-06 19:41:10','2021-02-06 19:41:10','cc618238-28cf-4074-9ba6-3390f1c0b199'),(4,1,NULL,1,NULL,'2021-02-06 19:41:00',NULL,NULL,'2021-02-06 19:41:18','2021-02-06 19:41:18','75b8d946-b387-4c64-86c5-87ceb120cfbf'),(9,2,NULL,2,1,'2021-02-06 19:42:00',NULL,1,'2021-02-06 19:42:26','2021-02-06 19:42:26','8e8457c5-9de3-45ac-9477-4ed1093c2188'),(11,2,NULL,2,1,'2021-02-06 19:42:00',NULL,NULL,'2021-02-06 19:42:27','2021-02-06 19:42:27','77b4924a-8999-4946-adbb-1f0b6fcd1b01'),(13,2,NULL,2,1,'2021-02-06 19:42:00',NULL,NULL,'2021-02-06 19:42:53','2021-02-06 19:42:53','7dd9cfdf-abe1-44c7-aad4-5b178bc9dc4e'),(15,2,NULL,2,1,'2021-02-06 19:42:00',NULL,NULL,'2021-02-06 19:45:15','2021-02-06 19:45:15','84155372-3f06-4e9b-8128-adeb7ea4ed0a'),(17,2,NULL,2,1,'2021-02-06 19:42:00',NULL,NULL,'2021-02-06 19:45:18','2021-02-06 19:45:18','52b02df7-8032-4a37-ad44-9adb63fede3a'),(19,2,NULL,2,1,'2021-02-06 19:42:00',NULL,NULL,'2021-02-06 19:47:31','2021-02-06 19:47:31','3bd2e80b-90b6-44b1-ab81-1ab396e414e1'),(21,3,NULL,3,1,'2021-02-06 19:48:00',NULL,NULL,'2021-02-06 19:48:37','2021-02-06 19:48:37','eebdf314-9e30-44df-a89d-a5e4f0fd261a'),(22,3,NULL,3,1,'2021-02-06 19:48:00',NULL,NULL,'2021-02-06 19:48:37','2021-02-06 19:48:37','53f4b1ec-3a4a-4ba5-b299-5b2b2fe410db');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8_unicode_ci,
  `titleFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ixbklhonoenuqzucqjoemvcfxymwinizkqgf` (`name`,`sectionId`),
  KEY `idx_kxxkqzjjjjbxbhwppbqfixfwilnxbjxrhbgl` (`handle`,`sectionId`),
  KEY `idx_qinufdfjnotgodzihcqsubxjkawyqclkgjou` (`sectionId`),
  KEY `idx_tvniunaissonkisvdqlmpukslukscbncknif` (`fieldLayoutId`),
  KEY `idx_revilmaztcmtapieyzipgtetpudlojvhlntr` (`dateDeleted`),
  CONSTRAINT `fk_sydobctudgdzmlbfmtvtivzvqpctcypexwwo` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tbdjwypljvcqdnumsfoqnpkbbkuxjuziaekr` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,7,'Homepage','homepage',0,'site',NULL,'{section.name|raw}',1,'2021-02-06 19:41:10','2021-02-06 19:41:10',NULL,'f65bcd77-9a38-47af-be23-9e3a721dc934'),(2,2,8,'User Guide','userGuide',1,'site',NULL,NULL,1,'2021-02-06 19:41:35','2021-02-06 19:41:35','2021-02-06 19:47:44','9958d1fe-c92b-422a-8113-6e7dafba0a8d'),(3,3,9,'User Guide','userGuide',1,'site',NULL,NULL,1,'2021-02-06 19:47:59','2021-02-06 19:47:59',NULL,'475a351b-2442-4767-8ab6-1b39216d0c61');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hevtumaugoorpzmhvwtlqfvdkyztembhljpb` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Common','2021-02-06 19:29:00','2021-02-06 19:29:00','ef8cc244-dfa8-41b1-945d-cb673ae71824'),(2,'User Guide','2021-02-06 19:33:29','2021-02-06 19:33:29','ca4cf186-4f48-488c-adbc-d38eba9d2533'),(3,'SEO','2021-02-06 19:33:32','2021-02-06 19:33:32','45625a48-7140-46aa-8d2c-e4a043c680a3');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wuntoqowbdzwabyhehvyljmtwupedkrxbbqd` (`layoutId`,`fieldId`),
  KEY `idx_amtizzqnbpsnduxcurktcbbhukmnqbbddmuc` (`sortOrder`),
  KEY `idx_hcohvbauspjnpddyowhohkwurnvhqlrbakmk` (`tabId`),
  KEY `idx_rksqmlodkftfthkgbiqqsrnnvcunpknflsgk` (`fieldId`),
  CONSTRAINT `fk_daockvumeaupbtkxrihdvtlsfsuhltinhujf` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mptfzqnfanyxdejdkoppbzdtdxmgwcdinyti` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ntwkqyubrqwnwfvnkerosgwgdptcpfuahnvm` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (15,7,11,1,0,0,'2021-02-06 19:41:18','2021-02-06 19:41:18','cf9c439f-6a29-4eaa-a282-39cb0f4a9fdd'),(27,2,18,3,0,0,'2021-02-06 19:44:23','2021-02-06 19:44:23','ef56dfb7-a888-4500-86e8-7b39adab5692'),(28,2,18,5,0,1,'2021-02-06 19:44:23','2021-02-06 19:44:23','d641fd60-fd93-404b-aa01-62152c91dfcb'),(29,2,18,4,0,2,'2021-02-06 19:44:23','2021-02-06 19:44:23','d5818f0e-cd61-4bf6-8aca-647cf38449a3'),(30,3,19,6,0,0,'2021-02-06 19:44:23','2021-02-06 19:44:23','a6de8ecd-8ecf-42de-b103-ce090946f9c4'),(31,3,19,7,0,1,'2021-02-06 19:44:23','2021-02-06 19:44:23','cbb76dac-4aaf-4ee8-80ff-4f5a7727552f'),(32,5,20,10,0,0,'2021-02-06 19:44:23','2021-02-06 19:44:23','1a0ccb72-29b7-4dd4-a28e-9da376d42c89'),(33,5,20,8,0,1,'2021-02-06 19:44:23','2021-02-06 19:44:23','228b6542-ece0-48fc-8dfd-c876384ffc8b'),(34,5,20,9,0,2,'2021-02-06 19:44:23','2021-02-06 19:44:23','c48aa48b-bec6-4ca9-8141-60be56c9d005'),(35,6,21,11,0,0,'2021-02-06 19:44:23','2021-02-06 19:44:23','a05e3170-6a91-4652-8cbb-90eecb33a597'),(36,6,21,12,0,1,'2021-02-06 19:44:23','2021-02-06 19:44:23','48632662-7135-452e-a656-c58bc2889cd2'),(37,8,23,2,0,1,'2021-02-06 19:46:27','2021-02-06 19:46:27','c7c1152e-e219-4252-b53a-9dee3f389f85'),(38,9,25,2,0,1,'2021-02-06 19:48:53','2021-02-06 19:48:53','e318c45e-eb01-449e-80d2-ae9e532c9f9b');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lhasrwjrlgceorpmjiixwrhrkxzfsrofvdee` (`dateDeleted`),
  KEY `idx_lewqdfbkmtotvzazeguhbgyqxdarzbvgluqh` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Asset','2021-02-06 19:34:44','2021-02-06 19:34:44',NULL,'b06de4af-a975-4b6c-8ef4-1c794da71432'),(2,'craft\\elements\\MatrixBlock','2021-02-06 19:36:17','2021-02-06 19:36:17',NULL,'623094d9-a7ca-4635-b4df-fb93c89d5b74'),(3,'craft\\elements\\MatrixBlock','2021-02-06 19:36:17','2021-02-06 19:36:17',NULL,'63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0'),(4,'craft\\elements\\Asset','2021-02-06 19:38:27','2021-02-06 19:38:27',NULL,'eb53ac7e-fc3b-4522-a428-91addf2ec44f'),(5,'craft\\elements\\MatrixBlock','2021-02-06 19:40:45','2021-02-06 19:40:45',NULL,'bc2a4d96-e189-4577-9559-d25bf551d2c1'),(6,'craft\\elements\\MatrixBlock','2021-02-06 19:40:45','2021-02-06 19:40:45',NULL,'2be8891e-b97f-4d20-8c96-63ee3acef638'),(7,'craft\\elements\\Entry','2021-02-06 19:41:10','2021-02-06 19:41:10',NULL,'0370a645-18d3-48e4-891a-13bc65ceb1ae'),(8,'craft\\elements\\Entry','2021-02-06 19:41:35','2021-02-06 19:41:35','2021-02-06 19:47:44','45e2ecf7-f4aa-4514-be41-7f8840b1cd20'),(9,'craft\\elements\\Entry','2021-02-06 19:47:59','2021-02-06 19:47:59',NULL,'b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elements` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rvjdbbwaofklxukbogqfjxhsbgeikxklyfky` (`sortOrder`),
  KEY `idx_bxbmtlihvfvydlzkipvnmfnxdpdfnzdxdkuo` (`layoutId`),
  CONSTRAINT `fk_ceclcaruwwgvdmzvunpppsrioawtiictftyg` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (1,1,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100}]',1,'2021-02-06 19:34:44','2021-02-06 19:34:44','a63bb995-9c69-43fa-90f6-628a09e38bf1'),(4,4,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100}]',1,'2021-02-06 19:38:27','2021-02-06 19:38:27','48e51ef2-0b92-47d5-8236-52934f621fb6'),(10,7,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100}]',1,'2021-02-06 19:41:18','2021-02-06 19:41:18','3aac0132-ef5f-477f-a08e-8a0d0bad7a88'),(11,7,'SEO','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"149ec41c-d6de-4ae5-84db-08d285801dd1\"}]',2,'2021-02-06 19:41:18','2021-02-06 19:41:18','ea40d0a5-8eb6-4a76-9e3a-a1b696ce4a8c'),(18,2,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"01d20550-63a0-4d7a-ad9b-5a130e8f55a8\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"6adad598-392d-4158-9400-8f90f7fe1fb0\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"10748c54-7d1f-4b35-9fd9-57bb11a751bc\"}]',1,'2021-02-06 19:44:23','2021-02-06 19:44:23','e1a117ae-6930-4169-b0c6-525abba96b59'),(19,3,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"25e2157e-9a82-41cd-970f-4fc58cb3a835\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"f03239f9-af65-481a-b6b8-76e0e158244f\"}]',1,'2021-02-06 19:44:23','2021-02-06 19:44:23','1f728f66-64a4-4bcc-9e70-0e2bebe42c17'),(20,5,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"854806b9-7b9c-4bee-b636-6ffb1d144b34\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"505d226e-5fae-49b8-9460-b78c35449b2e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"6f74be98-1b1b-470e-a96a-727b01e0b225\"}]',1,'2021-02-06 19:44:23','2021-02-06 19:44:23','56c54d1a-0bc9-493a-a342-789511c65600'),(21,6,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"14e1bd82-34c0-42c5-a72d-1d002d9775d2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"158c7930-10bb-483f-8328-c8aa657d8647\"}]',1,'2021-02-06 19:44:23','2021-02-06 19:44:23','22553107-05a0-4b71-be18-0d3a3d8035b8'),(23,8,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"d974bf8d-647d-45f3-98be-0733d5e3e1ba\"}]',1,'2021-02-06 19:46:27','2021-02-06 19:46:27','b259e0e8-48f6-4b5b-9a01-23c3d3b577e4'),(25,9,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"d974bf8d-647d-45f3-98be-0733d5e3e1ba\"}]',1,'2021-02-06 19:48:53','2021-02-06 19:48:53','66491234-e3c0-4ccc-bde5-9bae259400db');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8_unicode_ci,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `translationKeyFormat` text COLLATE utf8_unicode_ci,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ljlidbxfaukiawbqljkbaqkjvfqlwqmplear` (`handle`,`context`),
  KEY `idx_aevmovtfabymrybslgoxettipqahsgztvdrw` (`groupId`),
  KEY `idx_lsdnwtjerlghypfgwpnbyulchxobyhnzytkv` (`context`),
  CONSTRAINT `fk_jdyqafnmnzannkoysllaiosuukkwlotgords` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,3,'SEO','seo','global','',0,'none',NULL,'nystudio107\\seomatic\\fields\\SeoSettings','{\"elementDisplayPreviewType\":\"google\",\"facebookEnabledFields\":[\"seoPreview\",\"ogTitle\",\"ogDescription\",\"ogImage\"],\"facebookTabEnabled\":\"1\",\"generalEnabledFields\":[\"seoPreview\",\"seoTitle\",\"seoDescription\",\"seoImage\"],\"generalTabEnabled\":\"1\",\"sitemapEnabledFields\":[\"sitemapUrls\",\"sitemapChangeFreq\",\"sitemapPriority\"],\"sitemapTabEnabled\":\"1\",\"twitterEnabledFields\":[\"seoPreview\",\"twitterTitle\",\"twitterDescription\",\"twitterImage\"],\"twitterTabEnabled\":\"1\"}','2021-02-06 19:33:41','2021-02-06 19:34:19','149ec41c-d6de-4ae5-84db-08d285801dd1'),(2,2,'User Guide','userGuide','global','',0,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_userguide}}\",\"maxBlocks\":\"\",\"minBlocks\":\"\",\"propagationMethod\":\"all\"}','2021-02-06 19:36:17','2021-02-06 19:36:17','d974bf8d-647d-45f3-98be-0733d5e3e1ba'),(3,NULL,'Section Title','sectionTitle','matrixBlockType:0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2021-02-06 19:36:17','2021-02-06 19:36:17','01d20550-63a0-4d7a-ad9b-5a130e8f55a8'),(4,NULL,'Copy','copy','matrixBlockType:0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29','',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"cleanupHtml\":true,\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\",\"showHtmlButtonForNonAdmins\":\"\",\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2021-02-06 19:36:17','2021-02-06 19:36:17','10748c54-7d1f-4b35-9fd9-57bb11a751bc'),(5,NULL,'Section Subtitle','sectionSubtitle','matrixBlockType:0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2021-02-06 19:36:17','2021-02-06 19:36:17','6adad598-392d-4158-9400-8f90f7fe1fb0'),(6,NULL,'Screenshots','screenshots','matrixBlockType:4427e835-20ed-496b-9469-831bb0882185','',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"1\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"singleUploadLocationSource\":\"volume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":[\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\"],\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2021-02-06 19:36:17','2021-02-06 19:40:45','25e2157e-9a82-41cd-970f-4fc58cb3a835'),(7,NULL,'Caption','caption','matrixBlockType:4427e835-20ed-496b-9469-831bb0882185','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2021-02-06 19:40:45','2021-02-06 19:40:45','f03239f9-af65-481a-b6b8-76e0e158244f'),(8,NULL,'SectionSubtitle','sectionsubtitle','matrixBlockType:a399fb79-90a6-48a0-be1f-38d2b8a81af5','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2021-02-06 19:40:45','2021-02-06 19:40:45','505d226e-5fae-49b8-9460-b78c35449b2e'),(9,NULL,'Video Upload','videoUpload','matrixBlockType:a399fb79-90a6-48a0-be1f-38d2b8a81af5','',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"video\"],\"defaultUploadLocationSource\":\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"1\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"singleUploadLocationSource\":\"volume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":[\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\"],\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2021-02-06 19:40:45','2021-02-06 19:43:40','6f74be98-1b1b-470e-a96a-727b01e0b225'),(10,NULL,'Section Title','sectionTitle','matrixBlockType:a399fb79-90a6-48a0-be1f-38d2b8a81af5','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2021-02-06 19:40:45','2021-02-06 19:40:45','854806b9-7b9c-4bee-b636-6ffb1d144b34'),(11,NULL,'Video Title','videoTitle','matrixBlockType:c4527788-b877-44f3-9a2d-071f696877fa','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2021-02-06 19:40:45','2021-02-06 19:40:45','14e1bd82-34c0-42c5-a72d-1d002d9775d2'),(12,NULL,'Video ID','videoId','matrixBlockType:c4527788-b877-44f3-9a2d-071f696877fa','i.e. LTRD2wUQ4KY',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2021-02-06 19:40:45','2021-02-06 19:40:45','158c7930-10bb-483f-8328-c8aa657d8647');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hqwiittylsyexpyahxqvwtypwibmyxhqtcqg` (`name`),
  KEY `idx_erzgydsaevmyubnomtklkffuhqymefmahzbc` (`handle`),
  KEY `idx_jizvmlrdwgjhbcyrhhfktvthwrmwgohzcucy` (`fieldLayoutId`),
  CONSTRAINT `fk_cotydccckmwkkdwsexvqqcnkxdgxinjgukza` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prxmdrtkymxqcioeqjjbdrludjbzmtdpswct` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scope` text COLLATE utf8_unicode_ci,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accessToken` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oovjzjvyoqeyswrtafqovtwohaslwnfjzeig` (`accessToken`),
  UNIQUE KEY `idx_ufkidlxllljxqcbloyhomgwbkbnlsurghdjl` (`name`),
  KEY `fk_drdgxlkkbgrkzitarynxmvmqbqftzpqqsrqw` (`schemaId`),
  CONSTRAINT `fk_drdgxlkkbgrkzitarynxmvmqbqftzpqqsrqw` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'3.6.4.1','3.6.1',0,'ridwexmmumht','ghfqnwumeqxs','2021-02-06 19:29:00','2021-02-20 17:52:08','eb1e534a-9750-4fae-b8e8-334b58c78065');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rsfycqjiseksvxmjeagitpxofhgbhmztmepq` (`ownerId`),
  KEY `idx_avuwxyvowglbkquuvqisjafvsiszeqntppdt` (`fieldId`),
  KEY `idx_xqikxhjwtcqwwamevlplewpxphfvzfbymfbr` (`typeId`),
  KEY `idx_rhrmkuzlwxjiptyvfhkbtwnvoyzjzvybmtyx` (`sortOrder`),
  CONSTRAINT `fk_fhcwzfdkejqhaalndqkngjmevkqspizhsltc` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gqhelklkfkxwjtehzmqxdjfsfsalqxateexk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jbxprptjfgzhtvryofoeltlxhahvzlgvdcct` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mrxmmelqjvahjetgmzvzwixmhslszxyrrpid` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
INSERT INTO `matrixblocks` VALUES (10,9,2,1,1,0,'2021-02-06 19:42:26','2021-02-06 19:42:26','a87b4e2c-c8f5-41aa-8032-1cfc1c6f6ddc'),(12,11,2,1,1,NULL,'2021-02-06 19:42:27','2021-02-06 19:42:27','70e5a5f5-f724-4fd8-9660-85917571f638'),(14,13,2,1,1,NULL,'2021-02-06 19:42:53','2021-02-06 19:42:53','7f4f3e32-3bef-4bfe-bd2b-c3e6e6458a75'),(16,15,2,1,1,NULL,'2021-02-06 19:45:15','2021-02-06 19:45:15','dcec6d6b-935c-4531-8b5f-bc5ce49573a2'),(18,17,2,1,1,NULL,'2021-02-06 19:45:18','2021-02-06 19:45:18','28b4b066-ff94-409c-ad88-58c46225e3df');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hrqzjpvhpcovpofqpwvfdrrtrvmngrscqeow` (`name`,`fieldId`),
  KEY `idx_prmdiubidfsimiamgthgxutycxomtlkwezyw` (`handle`,`fieldId`),
  KEY `idx_qwoovgeueddizfhbrghdvxpdsuyzrvfeizuz` (`fieldId`),
  KEY `idx_mdcqwgwxxkneprdfrljzdprvjkdewyiummpo` (`fieldLayoutId`),
  CONSTRAINT `fk_aamfwjgohlwymiawwojjfpnqlsmlofeujykp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zohwfcvougopkczunglnpkbstvcfqsrtogwr` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
INSERT INTO `matrixblocktypes` VALUES (1,2,2,'Copy','copy',1,'2021-02-06 19:36:17','2021-02-06 19:36:17','0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29'),(2,2,3,'Image','image',2,'2021-02-06 19:36:17','2021-02-06 19:36:17','4427e835-20ed-496b-9469-831bb0882185'),(3,2,5,'Video','video',3,'2021-02-06 19:40:45','2021-02-06 19:40:45','a399fb79-90a6-48a0-be1f-38d2b8a81af5'),(4,2,6,'YouTube Video','youtubeVideo',4,'2021-02-06 19:40:45','2021-02-06 19:40:45','c4527788-b877-44f3-9a2d-071f696877fa');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixcontent_userguide`
--

DROP TABLE IF EXISTS `matrixcontent_userguide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_userguide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `field_copy_sectionTitle` text COLLATE utf8_unicode_ci,
  `field_copy_copy` text COLLATE utf8_unicode_ci,
  `field_copy_sectionSubtitle` text COLLATE utf8_unicode_ci,
  `field_image_caption` text COLLATE utf8_unicode_ci,
  `field_video_sectionsubtitle` text COLLATE utf8_unicode_ci,
  `field_video_sectionTitle` text COLLATE utf8_unicode_ci,
  `field_youtubeVideo_videoTitle` text COLLATE utf8_unicode_ci,
  `field_youtubeVideo_videoId` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bliokcxzvttresnuftjbvryejchwsywvzemb` (`elementId`,`siteId`),
  KEY `fk_qyzspuwhybuimcnhivfmdbinnthejmwrphln` (`siteId`),
  CONSTRAINT `fk_cvrudzbwweetlkwjmlsffmfcawnkwdbqeiex` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qyzspuwhybuimcnhivfmdbinnthejmwrphln` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixcontent_userguide`
--

LOCK TABLES `matrixcontent_userguide` WRITE;
/*!40000 ALTER TABLE `matrixcontent_userguide` DISABLE KEYS */;
INSERT INTO `matrixcontent_userguide` VALUES (1,6,2,'2021-02-06 19:42:15','2021-02-06 19:42:15','d04db601-9616-449f-a5b9-891fc89aa1c3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,7,2,'2021-02-06 19:42:18','2021-02-06 19:42:18','a5fe1ff1-4c2b-4243-90e4-acd71f35c835','General',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,10,2,'2021-02-06 19:42:26','2021-02-06 19:45:18','91e5f29a-efe5-40a8-91b1-590cfc87f46d','General','<p>some copy goes here</p>','dsafsd',NULL,NULL,NULL,NULL,NULL),(5,12,2,'2021-02-06 19:42:27','2021-02-06 19:42:27','066e836a-4e34-46b8-b039-7d1902cdf2c7','General','<p>some copy goes here</p>',NULL,NULL,NULL,NULL,NULL,NULL),(6,14,2,'2021-02-06 19:42:53','2021-02-06 19:42:53','0a0a0fc4-bdfd-4744-b36f-06c03ead9b80','General','<p>some copy goes here</p>',NULL,NULL,NULL,NULL,NULL,NULL),(7,16,2,'2021-02-06 19:45:15','2021-02-06 19:45:15','8898f2ee-2244-41d8-9350-09e21c167d22','General','<p>some copy goes here</p>',NULL,NULL,NULL,NULL,NULL,NULL),(8,18,2,'2021-02-06 19:45:18','2021-02-06 19:45:18','57919f75-1752-40e3-9fef-49ca06712022','General','<p>some copy goes here</p>','dsafsd',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `matrixcontent_userguide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dzbmuylpvyozuvyyclzwmcrkcwgttwlfccmy` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (12,'craft','Install','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9f7d0ced-bb0d-4319-8fc7-f4f6a5171ab8'),(13,'craft','m150403_183908_migrations_table_changes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c068ebe8-1ea5-47cf-82dd-95801d6f8215'),(14,'craft','m150403_184247_plugins_table_changes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','59f57db6-6119-4542-9801-5c31078e4a68'),(15,'craft','m150403_184533_field_version','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b4ea93ca-cb0b-4a3c-909c-65be11620cba'),(16,'craft','m150403_184729_type_columns','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9313e318-cdad-4b8b-af58-9edf8d9b57bb'),(17,'craft','m150403_185142_volumes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9b71cc2f-5083-41f3-85b2-a72478112fe0'),(18,'craft','m150428_231346_userpreferences','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','8219d395-0709-4a4d-b81c-9f9d0732501c'),(19,'craft','m150519_150900_fieldversion_conversion','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2f051573-2fa1-40ee-85db-95c03a34935a'),(20,'craft','m150617_213829_update_email_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b3e2e930-c7dd-4086-b2fa-c9198ca325ad'),(21,'craft','m150721_124739_templatecachequeries','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','4c8c8476-ee57-4793-9ac2-da0bd3494c1f'),(22,'craft','m150724_140822_adjust_quality_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f26b4812-a8e4-4c85-aa4c-9d00333e5558'),(23,'craft','m150815_133521_last_login_attempt_ip','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','551b9371-537d-4960-a71c-88dfa5750cec'),(24,'craft','m151002_095935_volume_cache_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','490cb9bd-d554-4488-9232-19260378c9e3'),(25,'craft','m151005_142750_volume_s3_storage_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','39d8b979-1615-4f82-9ebb-63fb41d14b36'),(26,'craft','m151016_133600_delete_asset_thumbnails','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','0f4bbdad-b5f0-4c24-881d-11dacf7d63b9'),(27,'craft','m151209_000000_move_logo','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c8d5f101-7955-4ab4-b872-318c7f23fbb2'),(28,'craft','m151211_000000_rename_fileId_to_assetId','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','381be32a-840a-4424-a863-0cb69671aee7'),(29,'craft','m151215_000000_rename_asset_permissions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','0d53840f-bf2e-4bbd-a5d7-7eef1b2d335f'),(30,'craft','m160707_000001_rename_richtext_assetsource_setting','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3bcf749c-b0e8-44e6-b5d3-bd1685189b1f'),(31,'craft','m160708_185142_volume_hasUrls_setting','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f9be56db-f0e0-454d-82eb-8994f9a9a075'),(32,'craft','m160714_000000_increase_max_asset_filesize','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','4388b436-aed2-4055-bd06-471737476e9c'),(33,'craft','m160727_194637_column_cleanup','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','4ad1a72d-3f8b-45de-80d1-9fae2660c54a'),(34,'craft','m160804_110002_userphotos_to_assets','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b97d0d7d-c15e-4bff-82da-bd5bcd071314'),(35,'craft','m160807_144858_sites','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','49eaff79-d947-480d-a1ea-284405602fc6'),(36,'craft','m160829_000000_pending_user_content_cleanup','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','001eea38-6e32-4062-8d3e-cbac766444c0'),(37,'craft','m160830_000000_asset_index_uri_increase','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','d2f49183-31d7-4a0c-a009-a9c984fce8a2'),(38,'craft','m160912_230520_require_entry_type_id','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','42b5c26a-4344-4c7f-b5c2-6fc0d54dd316'),(39,'craft','m160913_134730_require_matrix_block_type_id','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','6d37a6b8-08d4-4632-b7cb-2ed2fee79098'),(40,'craft','m160920_174553_matrixblocks_owner_site_id_nullable','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','d4a9ea18-b64a-4a8e-98da-7a4c54930d12'),(41,'craft','m160920_231045_usergroup_handle_title_unique','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b30b31e7-dfaf-44e4-ba6a-dadd8f4ecfdc'),(42,'craft','m160925_113941_route_uri_parts','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c7f49d74-f8d0-42ba-9e4b-8fc6d0c1fd9a'),(43,'craft','m161006_205918_schemaVersion_not_null','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7f2727f4-5177-4273-bfb8-f07df6dd7e58'),(44,'craft','m161007_130653_update_email_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2d67862b-79b7-4216-89e4-57d787b2eb6a'),(45,'craft','m161013_175052_newParentId','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c16be0ae-7f66-492e-bf0d-cd396d5e6fe5'),(46,'craft','m161021_102916_fix_recent_entries_widgets','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','38bdcfe3-44fc-4944-8088-ac6f362fa811'),(47,'craft','m161021_182140_rename_get_help_widget','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','09fc9710-4fc8-4bca-bc5e-0422b92595fb'),(48,'craft','m161025_000000_fix_char_columns','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3b847b55-befe-4419-a3a2-da03827a110c'),(49,'craft','m161029_124145_email_message_languages','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','73c5a3b2-f656-4d68-a238-c8afc803a3e6'),(50,'craft','m161108_000000_new_version_format','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7ec7db22-eb28-4927-93bf-3cde816f4edb'),(51,'craft','m161109_000000_index_shuffle','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2ddcc320-8cf7-487c-a781-267c60f7b490'),(52,'craft','m161122_185500_no_craft_app','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','faa9e103-adc6-437c-86ae-b6893342cf05'),(53,'craft','m161125_150752_clear_urlmanager_cache','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','fad38097-7b4f-4b77-8069-db4c31854555'),(54,'craft','m161220_000000_volumes_hasurl_notnull','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b1b3103b-276f-4665-866d-7019884d299a'),(55,'craft','m170114_161144_udates_permission','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2b448dcf-b0f7-4f86-a896-27fed0bb2295'),(56,'craft','m170120_000000_schema_cleanup','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','11257941-6d80-474e-b11e-ffcaffda5490'),(57,'craft','m170126_000000_assets_focal_point','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','6a8c56df-6577-44cd-905c-01a8181efcd8'),(58,'craft','m170206_142126_system_name','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','11955a6d-d2b9-47a2-8055-ac65f953beca'),(59,'craft','m170217_044740_category_branch_limits','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','8e8aa2f6-2e6c-4505-9997-13fd7f0a8ac6'),(60,'craft','m170217_120224_asset_indexing_columns','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','0b22d45f-82f2-4c8e-9bb5-4000b2afe8e9'),(61,'craft','m170223_224012_plain_text_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','dcc02270-cecc-4dad-8461-d4c118a043c9'),(62,'craft','m170227_120814_focal_point_percentage','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9a89c749-8cb6-49e6-88a4-62504de3676e'),(63,'craft','m170228_171113_system_messages','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7544d508-7d14-4706-9b67-56df550cf09c'),(64,'craft','m170303_140500_asset_field_source_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','28a55a86-15fb-4e7b-81d9-fc6b3cc0dd44'),(65,'craft','m170306_150500_asset_temporary_uploads','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9e590c85-f24f-4abd-8bf2-814799d4446a'),(66,'craft','m170523_190652_element_field_layout_ids','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','cf178d88-bb77-473e-b01a-2c8f308e2276'),(67,'craft','m170621_195237_format_plugin_handles','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7360a814-1c53-4ca5-b78b-6c1161e40ce3'),(68,'craft','m170630_161027_deprecation_line_nullable','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','6764cc4c-a693-4435-b942-998b3563afb7'),(69,'craft','m170630_161028_deprecation_changes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','25e51055-8e99-42b4-863a-f0e2565cfe74'),(70,'craft','m170703_181539_plugins_table_tweaks','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','e33942d5-2c73-483a-9126-9451cce697fe'),(71,'craft','m170704_134916_sites_tables','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','09868b10-c3d1-4a83-b2bc-27b75b12f669'),(72,'craft','m170706_183216_rename_sequences','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','e1f8b759-077f-483e-82ea-f8d4e9b206f6'),(73,'craft','m170707_094758_delete_compiled_traits','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b6559436-47f1-4833-9206-e5b551839431'),(74,'craft','m170731_190138_drop_asset_packagist','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','dbac3702-0a4d-4381-a0ce-1bfa697dc45c'),(75,'craft','m170810_201318_create_queue_table','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7b771ffc-9962-47ff-a8c3-780be37079d8'),(76,'craft','m170903_192801_longblob_for_queue_jobs','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','98d7ec65-f84a-4885-8983-e40c40c51aaf'),(77,'craft','m170914_204621_asset_cache_shuffle','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c931fe84-abf4-4436-9c4a-4a5f10340a46'),(78,'craft','m171011_214115_site_groups','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f5155773-0596-40f9-b4b6-79aa8216bba0'),(79,'craft','m171012_151440_primary_site','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','8adce863-6b35-4cae-adc1-87c42f556f91'),(80,'craft','m171013_142500_transform_interlace','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7cfdd293-6f5e-4631-a9ff-a1b728bda5bd'),(81,'craft','m171016_092553_drop_position_select','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','ab5ba98b-5bec-452c-a103-404180a98baa'),(82,'craft','m171016_221244_less_strict_translation_method','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','789162aa-9f6a-45d4-b02a-57b30e17398e'),(83,'craft','m171107_000000_assign_group_permissions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','d9c333a4-de97-43d0-acb7-5e41510a5d64'),(84,'craft','m171117_000001_templatecache_index_tune','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9d9b1c63-39f3-40dc-8f56-3f522c8b8cb5'),(85,'craft','m171126_105927_disabled_plugins','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','ab5ecd1d-637a-47ee-a857-08cb0626f1f9'),(86,'craft','m171130_214407_craftidtokens_table','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','4ac0d584-b2cb-4835-9640-5a1227c15846'),(87,'craft','m171202_004225_update_email_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','046d4fbd-669a-419d-a23c-e66f290e0624'),(88,'craft','m171204_000001_templatecache_index_tune_deux','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3c8b3eb1-debf-4299-b8ce-8a9444f879c0'),(89,'craft','m171205_130908_remove_craftidtokens_refreshtoken_column','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c8c04a56-439d-4c00-8de5-dcc29e172245'),(90,'craft','m171218_143135_longtext_query_column','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f89c434d-35ca-44b2-b63b-8bbf86d918bb'),(91,'craft','m171231_055546_environment_variables_to_aliases','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','8b2052b6-fcaa-46ca-848e-859f8a87a6f0'),(92,'craft','m180113_153740_drop_users_archived_column','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','ccbc1979-93e1-4456-9e59-6f7b8470100c'),(93,'craft','m180122_213433_propagate_entries_setting','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a78ade97-03d0-4329-9e30-1164f7f661a7'),(94,'craft','m180124_230459_fix_propagate_entries_values','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','42e35997-a5fb-4557-b3b6-8d175ad6333e'),(95,'craft','m180128_235202_set_tag_slugs','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','14ff4b1c-a30c-4c3f-bd86-d67dae921c69'),(96,'craft','m180202_185551_fix_focal_points','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3fe4103a-f4b5-437f-89d8-50024c0520c0'),(97,'craft','m180217_172123_tiny_ints','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a2c19c66-8077-41df-a375-46fcd2878eca'),(98,'craft','m180321_233505_small_ints','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','cfaed6dd-350a-4700-b8b3-f357994c1e91'),(99,'craft','m180404_182320_edition_changes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','62ee6cd1-0c24-45e1-85c3-e54a6b59fcd6'),(100,'craft','m180411_102218_fix_db_routes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7e432c7e-c439-45fe-9ada-64365ed80bb5'),(101,'craft','m180416_205628_resourcepaths_table','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','33b75977-1e84-4081-8c56-2154e4fc0342'),(102,'craft','m180418_205713_widget_cleanup','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','e9c9c763-6511-4f4a-b1b6-3219ecd2f83a'),(103,'craft','m180425_203349_searchable_fields','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f5534bd9-bdc1-44b7-af25-47e3321a0854'),(104,'craft','m180516_153000_uids_in_field_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','47d3671f-fe3f-4d55-a308-3c5bf79a33b8'),(105,'craft','m180517_173000_user_photo_volume_to_uid','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','85cdc873-19e4-4699-99f5-a7c8869c47f9'),(106,'craft','m180518_173000_permissions_to_uid','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','ae808741-4233-467d-a608-0a410d5fbaee'),(107,'craft','m180520_173000_matrix_context_to_uids','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a4a963b3-4162-4151-8dee-1f7c7f90f5f3'),(108,'craft','m180521_172900_project_config_table','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','06105b2b-4225-4cab-85c8-666786390015'),(109,'craft','m180521_173000_initial_yml_and_snapshot','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','0bf8ee38-8ea4-4878-bb41-61a49e03acbd'),(110,'craft','m180731_162030_soft_delete_sites','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a6dce08b-b1be-44e8-afd6-5d78e3be4fae'),(111,'craft','m180810_214427_soft_delete_field_layouts','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','732c9622-da0e-4236-9cab-2e77895a7d39'),(112,'craft','m180810_214439_soft_delete_elements','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','14202eb9-20b9-48a1-83f7-4d6ea31b1a5e'),(113,'craft','m180824_193422_case_sensitivity_fixes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','1c232cd1-ef39-459f-89db-f7c621223207'),(114,'craft','m180901_151639_fix_matrixcontent_tables','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','07786c5e-8b3b-4ecf-9a0f-75433a6ded16'),(115,'craft','m180904_112109_permission_changes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','89c4f132-92f2-4077-aa5e-4a59fdd8ee41'),(116,'craft','m180910_142030_soft_delete_sitegroups','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','19f0ea86-49d4-4c00-bc76-0c5d08862885'),(117,'craft','m181011_160000_soft_delete_asset_support','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','76f2b279-c7ef-4f26-8f6b-598148e15316'),(118,'craft','m181016_183648_set_default_user_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','04a25e81-25c5-4dcd-9099-f2c261c89f1d'),(119,'craft','m181017_225222_system_config_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','bad5d369-61da-4cb3-a899-bd198c4a5dcc'),(120,'craft','m181018_222343_drop_userpermissions_from_config','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','11dc1978-c770-40ce-9d76-6bf211d49d39'),(121,'craft','m181029_130000_add_transforms_routes_to_config','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','de9a996b-bd78-49cc-a7da-6691b6460c22'),(122,'craft','m181112_203955_sequences_table','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','386b620d-2b5d-4911-bb6f-da25eebe457c'),(123,'craft','m181121_001712_cleanup_field_configs','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','0178b1cf-0f31-4dc9-957a-f079f7ceed56'),(124,'craft','m181128_193942_fix_project_config','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b868adb0-afc2-4fa8-af32-9f04a44d5608'),(125,'craft','m181130_143040_fix_schema_version','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','8a9352d8-4c43-4141-b6f9-cedfef6b5bed'),(126,'craft','m181211_143040_fix_entry_type_uids','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a98cdf22-03a0-4c14-b137-9ab3d80544d6'),(127,'craft','m181217_153000_fix_structure_uids','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2f1c4b80-8111-4e7f-adf2-c022873d634b'),(128,'craft','m190104_152725_store_licensed_plugin_editions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3e093da3-7e31-4d0a-9aba-3f18c641b535'),(129,'craft','m190108_110000_cleanup_project_config','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','0514d97e-d26e-465f-a947-873ab3e64c0d'),(130,'craft','m190108_113000_asset_field_setting_change','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','d5a61fe8-89c9-4bbf-952d-092e2e06af0f'),(131,'craft','m190109_172845_fix_colspan','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','4fe63da9-5a26-42ce-848a-0cf0ab181acf'),(132,'craft','m190110_150000_prune_nonexisting_sites','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7485494a-a770-4686-b4a3-78ab52444313'),(133,'craft','m190110_214819_soft_delete_volumes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a2539ac5-b62b-4cc6-a7b5-cf254986d3e0'),(134,'craft','m190112_124737_fix_user_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f2870e4a-c781-4a3d-bffa-f2b0cff62e25'),(135,'craft','m190112_131225_fix_field_layouts','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9b9b80a8-cbd3-4ace-a9d6-35263d43f327'),(136,'craft','m190112_201010_more_soft_deletes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2a936090-fd7d-4057-97fe-b5cb346aae21'),(137,'craft','m190114_143000_more_asset_field_setting_changes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','0b1f30cd-9d8b-46df-9877-56c238ee99fa'),(138,'craft','m190121_120000_rich_text_config_setting','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a51650e8-86f5-4806-952a-97de80d115cc'),(139,'craft','m190125_191628_fix_email_transport_password','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','d71011c8-808d-457f-a1f7-ecac81d01e57'),(140,'craft','m190128_181422_cleanup_volume_folders','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9453f9b6-370f-4ffe-969e-540e03c822a1'),(141,'craft','m190205_140000_fix_asset_soft_delete_index','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','589c5645-7753-4fd1-858f-82ffc0789088'),(142,'craft','m190218_143000_element_index_settings_uid','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','760870fd-f2b0-4af9-a8cf-1e828e3f0e7d'),(143,'craft','m190312_152740_element_revisions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9cfea683-ebc3-4626-8711-666c27d0fbaa'),(144,'craft','m190327_235137_propagation_method','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7d8d8fe3-2b01-43df-9354-2800c39e0117'),(145,'craft','m190401_223843_drop_old_indexes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','b7608773-c4df-43df-a509-8074573b1017'),(146,'craft','m190416_014525_drop_unique_global_indexes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c62cc741-fe8f-457d-8b75-160e9048e652'),(147,'craft','m190417_085010_add_image_editor_permissions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','fc8e4d62-1079-4dac-a54d-c45973b8abfa'),(148,'craft','m190502_122019_store_default_user_group_uid','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c1a92a10-1707-4d27-839e-3c2d50327ddd'),(149,'craft','m190504_150349_preview_targets','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7d436330-3690-40db-8f06-179608182228'),(150,'craft','m190516_184711_job_progress_label','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3a161094-51f6-48a2-8adf-2a0645c1050b'),(151,'craft','m190523_190303_optional_revision_creators','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7c1f331b-6000-49a6-a747-63c520ef9f9e'),(152,'craft','m190529_204501_fix_duplicate_uids','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','9ba2cbbf-7c16-4230-8d80-4d75a3c7c85b'),(153,'craft','m190605_223807_unsaved_drafts','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','729a58fd-15d8-4a33-81e4-fe24e41443da'),(154,'craft','m190607_230042_entry_revision_error_tables','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3d324380-0366-46a7-a712-6e217f479ed5'),(155,'craft','m190608_033429_drop_elements_uid_idx','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2123f249-312c-4d61-9744-d908645551d3'),(156,'craft','m190617_164400_add_gqlschemas_table','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','1af52a59-b00b-4a57-b3a9-225e2f85ffd4'),(157,'craft','m190624_234204_matrix_propagation_method','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','6014cb54-9689-4795-b19e-5ff543692676'),(158,'craft','m190711_153020_drop_snapshots','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f27713ef-7bb0-43d2-87f2-5b35bdd181c6'),(159,'craft','m190712_195914_no_draft_revisions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','60638555-dd24-44da-92ba-9c6c9dcf5822'),(160,'craft','m190723_140314_fix_preview_targets_column','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a813021b-9260-4184-a207-c4bd6f52ac97'),(161,'craft','m190820_003519_flush_compiled_templates','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a0b4ce60-bece-445e-9113-7ae73c12e8bd'),(162,'craft','m190823_020339_optional_draft_creators','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','d9a45dfe-048f-4351-a30d-6a642614f777'),(163,'craft','m190913_152146_update_preview_targets','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','7282aa8f-8a7e-48d8-9b12-49c044d496c1'),(164,'craft','m191107_122000_add_gql_project_config_support','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','10d361d0-af25-4f87-96fc-435e97c0208e'),(165,'craft','m191204_085100_pack_savable_component_settings','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','c6f56eb3-9173-45f1-8c00-8c6ba2344bfa'),(166,'craft','m191206_001148_change_tracking','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','8699c7f1-24ec-4b0b-8c91-788af2dc171e'),(167,'craft','m191216_191635_asset_upload_tracking','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a6c1b95a-01c5-4955-9535-f9bb3839f584'),(168,'craft','m191222_002848_peer_asset_permissions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','e95c7423-f201-472d-9c11-8764894079df'),(169,'craft','m200127_172522_queue_channels','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','98de42a5-5967-431e-98a9-6c4f4e3e5fd5'),(170,'craft','m200211_175048_truncate_element_query_cache','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3a78cbbe-eebb-446e-9ae0-1024f35b982e'),(171,'craft','m200213_172522_new_elements_index','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f083ca5a-aa3c-41bc-86e7-65ec2e42706e'),(172,'craft','m200228_195211_long_deprecation_messages','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','cc770502-9c53-46be-aa50-f729fb39e8fb'),(173,'craft','m200306_054652_disabled_sites','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','dfa36f6c-d869-4558-8578-a685d4216acf'),(174,'craft','m200522_191453_clear_template_caches','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','8b98698c-7f38-43ef-8921-4c650d342c92'),(175,'craft','m200606_231117_migration_tracks','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','5cc13f66-2ea2-4b46-887c-de42a6ceb7ce'),(176,'craft','m200619_215137_title_translation_method','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','bb48fcaf-80ce-4806-9e50-e81802eefb9b'),(177,'craft','m200620_005028_user_group_descriptions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','ada8aca7-ab46-4b97-b958-d7a46c8b5cd1'),(178,'craft','m200620_230205_field_layout_changes','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','2510ad1a-47bf-4ea2-8e5d-44c38fe1c52a'),(179,'craft','m200625_131100_move_entrytypes_to_top_project_config','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','f308c4c6-274d-4c34-911b-ac4efc7c4d6f'),(180,'craft','m200629_112700_remove_project_config_legacy_files','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','664d58b9-94e4-4782-ac91-9b75cb21f782'),(181,'craft','m200630_183000_drop_configmap','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','a209d7be-b953-4072-9a72-a9534061b1cb'),(182,'craft','m200715_113400_transform_index_error_flag','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','3201525f-1380-4676-ba56-b2717ab0e80c'),(183,'craft','m200716_110900_replace_file_asset_permissions','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','659fd3a3-75f1-41f0-81d0-903589271106'),(184,'craft','m200716_153800_public_token_settings_in_project_config','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','e0e0ccdf-dafb-422c-ba57-bf6c8f806cfd'),(185,'craft','m200720_175543_drop_unique_constraints','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','bff52a3e-a433-4a5b-a58a-a94ef2dc714b'),(186,'craft','m200825_051217_project_config_version','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','44463ae1-fedb-4d98-84b4-2263d7236518'),(187,'craft','m201116_190500_asset_title_translation_method','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','d7a2eb12-4355-412e-82ab-c5e2de27868b'),(188,'craft','m201124_003555_plugin_trials','2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-06 19:29:01','4ee02bb4-254f-416a-8776-001d6162cc96'),(189,'plugin:redactor','m180430_204710_remove_old_plugins','2021-02-06 19:32:44','2021-02-06 19:32:44','2021-02-06 19:32:44','b4d89f24-30ad-4001-9cbd-5559d8d7c7f3'),(190,'plugin:redactor','Install','2021-02-06 19:32:44','2021-02-06 19:32:44','2021-02-06 19:32:44','c741b6f9-12ac-4cb0-9872-db17551c02b8'),(191,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2021-02-06 19:32:44','2021-02-06 19:32:44','2021-02-06 19:32:44','ce590cbc-2ca6-4c51-adc2-3ebff346b44b'),(192,'plugin:seomatic','Install','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','884523c9-9f35-436e-9b29-fa1e8f784d09'),(193,'plugin:seomatic','m180314_002755_field_type','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','9e1fca2d-5c3d-428b-b756-601052ba14d5'),(194,'plugin:seomatic','m180314_002756_base_install','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','e75bda40-cf17-4518-8e6e-c0981e5da61c'),(195,'plugin:seomatic','m180502_202319_remove_field_metabundles','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','a018fc94-1390-4303-927c-76309112a98a'),(196,'plugin:seomatic','m180711_024947_commerce_products','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','1d4f7d0b-e5fa-4dbe-a168-0146074bbba0'),(197,'plugin:seomatic','m190401_220828_longer_handles','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','e45fc71a-a0b7-49fe-9996-a706c192ca5d'),(198,'plugin:seomatic','m190518_030221_calendar_events','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','6905b3ad-1a1d-4bdf-aca9-61f82e489fcb'),(199,'plugin:seomatic','m200419_203444_add_type_id','2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-06 19:33:13','029a1047-16db-4bbe-beab-f3d9dcc94dd9');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cnszkqdreltjwgljdwgpojympbmxjkzgwzwc` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (8,'environment-label','3.2.0','1.0.0','unknown',NULL,'2021-02-06 19:32:37','2021-02-06 19:32:37','2021-02-20 18:00:35','18f95bba-1fea-43ad-bd60-4d3f16f44ca8'),(10,'minify','1.2.10','1.0.0','unknown',NULL,'2021-02-06 19:32:42','2021-02-06 19:32:42','2021-02-20 18:00:35','e532f42f-6216-442d-926f-698c08c34664'),(11,'redactor','2.8.5','2.3.0','unknown',NULL,'2021-02-06 19:32:44','2021-02-06 19:32:44','2021-02-20 18:00:35','db3bb3f0-c097-42c0-b362-01286c21ca5d'),(12,'retcon','2.2.1','1.0.0','unknown',NULL,'2021-02-06 19:32:47','2021-02-06 19:32:47','2021-02-20 18:00:35','8dd83aea-ebd0-433b-a3bb-e79cb0409637'),(13,'templatecomments','1.1.2','1.0.0','unknown',NULL,'2021-02-06 19:32:49','2021-02-06 19:32:49','2021-02-20 18:00:35','f0579cbd-c4a6-443e-8b87-75bc9e0c8aa4'),(14,'usermanual','2.0.5','2.0.1','unknown',NULL,'2021-02-06 19:32:51','2021-02-06 19:32:51','2021-02-20 18:00:35','c41a8121-5e31-4e79-bbab-8ed1d6e2cd17'),(15,'seomatic','3.3.30','3.0.9','invalid',NULL,'2021-02-06 19:33:13','2021-02-06 19:33:13','2021-02-20 18:00:35','b9aa7e19-7362-428d-9490-dfc01c1d33d5'),(16,'image-toolbox','1.0.0','1.0.0','unknown',NULL,'2021-02-20 17:52:08','2021-02-20 17:52:08','2021-02-20 18:00:35','a2525e55-898a-4c8c-add6-729c6805ac7a');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1613843528'),('email.fromEmail','\"$SYSTEM_EMAIL\"'),('email.fromName','\"$SENDER_NAME\"'),('email.replyToEmail','\"$FROM_EMAIL\"'),('email.template','null'),('email.transportSettings.encryptionMethod','\"\"'),('email.transportSettings.host','\"$EMAIL_HOSTNAME\"'),('email.transportSettings.password','\"$EMAIL_PASSWORD\"'),('email.transportSettings.port','\"$EMAIL_PORT\"'),('email.transportSettings.timeout','\"10\"'),('email.transportSettings.useAuthentication','\"1\"'),('email.transportSettings.username','\"$EMAIL_USERNAME\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Smtp\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.autocapitalize','true'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.autocomplete','false'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.autocorrect','true'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.class','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.disabled','false'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.id','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.instructions','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.label','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.max','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.min','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.name','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.orientation','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.placeholder','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.readonly','false'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.requirable','false'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.size','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.step','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.tip','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.title','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.warning','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.0.width','100'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.fieldUid','\"d974bf8d-647d-45f3-98be-0733d5e3e1ba\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.instructions','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.label','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.required','false'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.tip','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.warning','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.elements.1.width','100'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.name','\"Content\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.fieldLayouts.b0e00b72-8d9b-40b3-87a4-efcc1d0bc0ad.tabs.0.sortOrder','1'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.handle','\"userGuide\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.hasTitleField','true'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.name','\"User Guide\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.section','\"0784ad32-f952-40b1-9f6c-d0e67d502551\"'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.sortOrder','1'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.titleFormat','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.titleTranslationKeyFormat','null'),('entryTypes.475a351b-2442-4767-8ab6-1b39216d0c61.titleTranslationMethod','\"site\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.autocapitalize','true'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.autocomplete','false'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.autocorrect','true'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.class','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.disabled','false'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.id','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.instructions','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.label','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.max','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.min','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.name','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.orientation','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.placeholder','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.readonly','false'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.requirable','false'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.size','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.step','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.tip','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.title','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.warning','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.elements.0.width','100'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.name','\"Content\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.0.sortOrder','1'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.fieldUid','\"149ec41c-d6de-4ae5-84db-08d285801dd1\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.instructions','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.label','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.required','false'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.tip','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.warning','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.elements.0.width','100'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.name','\"SEO\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.fieldLayouts.0370a645-18d3-48e4-891a-13bc65ceb1ae.tabs.1.sortOrder','2'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.handle','\"homepage\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.hasTitleField','false'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.name','\"Homepage\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.section','\"722083b8-e7bc-4d95-b4dd-3473680b72a7\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.sortOrder','1'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.titleFormat','\"{section.name|raw}\"'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.titleTranslationKeyFormat','null'),('entryTypes.f65bcd77-9a38-47af-be23-9e3a721dc934.titleTranslationMethod','\"site\"'),('fieldGroups.45625a48-7140-46aa-8d2c-e4a043c680a3.name','\"SEO\"'),('fieldGroups.ca4cf186-4f48-488c-adbc-d38eba9d2533.name','\"User Guide\"'),('fieldGroups.ef8cc244-dfa8-41b1-945d-cb673ae71824.name','\"Common\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.contentColumnType','\"text\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.fieldGroup','\"45625a48-7140-46aa-8d2c-e4a043c680a3\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.handle','\"seo\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.instructions','\"\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.name','\"SEO\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.searchable','false'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.elementDisplayPreviewType','\"google\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.facebookEnabledFields.0','\"seoPreview\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.facebookEnabledFields.1','\"ogTitle\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.facebookEnabledFields.2','\"ogDescription\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.facebookEnabledFields.3','\"ogImage\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.facebookTabEnabled','\"1\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.generalEnabledFields.0','\"seoPreview\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.generalEnabledFields.1','\"seoTitle\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.generalEnabledFields.2','\"seoDescription\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.generalEnabledFields.3','\"seoImage\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.generalTabEnabled','\"1\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.sitemapEnabledFields.0','\"sitemapUrls\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.sitemapEnabledFields.1','\"sitemapChangeFreq\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.sitemapEnabledFields.2','\"sitemapPriority\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.sitemapTabEnabled','\"1\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.twitterEnabledFields.0','\"seoPreview\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.twitterEnabledFields.1','\"twitterTitle\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.twitterEnabledFields.2','\"twitterDescription\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.twitterEnabledFields.3','\"twitterImage\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.settings.twitterTabEnabled','\"1\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.translationKeyFormat','null'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.translationMethod','\"none\"'),('fields.149ec41c-d6de-4ae5-84db-08d285801dd1.type','\"nystudio107\\\\seomatic\\\\fields\\\\SeoSettings\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.contentColumnType','\"string\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.fieldGroup','\"ca4cf186-4f48-488c-adbc-d38eba9d2533\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.handle','\"userGuide\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.instructions','\"\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.name','\"User Guide\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.searchable','false'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.settings.contentTable','\"{{%matrixcontent_userguide}}\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.settings.maxBlocks','\"\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.settings.minBlocks','\"\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.settings.propagationMethod','\"all\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.translationKeyFormat','null'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.translationMethod','\"site\"'),('fields.d974bf8d-647d-45f3-98be-0733d5e3e1ba.type','\"craft\\\\fields\\\\Matrix\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.field','\"d974bf8d-647d-45f3-98be-0733d5e3e1ba\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.fieldUid','\"01d20550-63a0-4d7a-ad9b-5a130e8f55a8\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.label','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.required','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.tip','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.warning','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.0.width','100'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.fieldUid','\"6adad598-392d-4158-9400-8f90f7fe1fb0\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.label','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.required','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.tip','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.warning','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.1.width','100'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.fieldUid','\"10748c54-7d1f-4b35-9fd9-57bb11a751bc\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.label','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.required','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.tip','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.warning','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.elements.2.width','100'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.name','\"Content\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fieldLayouts.623094d9-a7ca-4635-b4df-fb93c89d5b74.tabs.0.sortOrder','1'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.contentColumnType','\"text\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.fieldGroup','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.handle','\"sectionTitle\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.instructions','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.name','\"Section Title\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.searchable','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.byteLimit','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.charLimit','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.code','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.columnType','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.initialRows','\"4\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.multiline','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.placeholder','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.settings.uiMode','\"normal\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.translationKeyFormat','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.translationMethod','\"none\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.01d20550-63a0-4d7a-ad9b-5a130e8f55a8.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.contentColumnType','\"text\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.fieldGroup','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.handle','\"copy\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.instructions','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.name','\"Copy\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.searchable','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.availableTransforms','\"*\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.availableVolumes','\"*\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.cleanupHtml','true'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.columnType','\"text\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.configSelectionMode','\"choose\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.defaultTransform','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.manualConfig','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.purifierConfig','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.purifyHtml','\"1\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.redactorConfig','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.removeEmptyTags','\"1\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.removeInlineStyles','\"1\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.removeNbsp','\"1\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.showHtmlButtonForNonAdmins','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.showUnpermittedFiles','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.settings.uiMode','\"enlarged\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.translationKeyFormat','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.translationMethod','\"none\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.10748c54-7d1f-4b35-9fd9-57bb11a751bc.type','\"craft\\\\redactor\\\\Field\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.contentColumnType','\"text\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.fieldGroup','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.handle','\"sectionSubtitle\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.instructions','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.name','\"Section Subtitle\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.searchable','false'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.byteLimit','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.charLimit','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.code','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.columnType','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.initialRows','\"4\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.multiline','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.placeholder','\"\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.settings.uiMode','\"normal\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.translationKeyFormat','null'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.translationMethod','\"none\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.fields.6adad598-392d-4158-9400-8f90f7fe1fb0.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.handle','\"copy\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.name','\"Copy\"'),('matrixBlockTypes.0187ae10-82fa-43e8-ac5c-e8fa4f2e3b29.sortOrder','1'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.field','\"d974bf8d-647d-45f3-98be-0733d5e3e1ba\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.fieldUid','\"25e2157e-9a82-41cd-970f-4fc58cb3a835\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.label','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.required','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.tip','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.warning','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.0.width','100'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.fieldUid','\"f03239f9-af65-481a-b6b8-76e0e158244f\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.label','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.required','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.tip','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.warning','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.elements.1.width','100'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.name','\"Content\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fieldLayouts.63e4bf4a-e003-4c1d-9c48-c8e7d9b987d0.tabs.0.sortOrder','1'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.contentColumnType','\"string\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.fieldGroup','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.handle','\"screenshots\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.instructions','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.name','\"Screenshots\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.searchable','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.allowedKinds.0','\"image\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.allowSelfRelations','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.allowUploads','true'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.defaultUploadLocationSource','\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.defaultUploadLocationSubpath','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.limit','\"1\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.localizeRelations','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.previewMode','\"full\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.restrictFiles','\"1\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.selectionLabel','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.showSiteMenu','true'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.showUnpermittedFiles','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.singleUploadLocationSource','\"volume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.singleUploadLocationSubpath','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.source','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.sources.0','\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.targetSiteId','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.useSingleFolder','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.validateRelatedElements','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.settings.viewMode','\"large\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.translationKeyFormat','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.translationMethod','\"site\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.25e2157e-9a82-41cd-970f-4fc58cb3a835.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.contentColumnType','\"text\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.fieldGroup','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.handle','\"caption\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.instructions','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.name','\"Caption\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.searchable','false'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.byteLimit','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.charLimit','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.code','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.columnType','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.initialRows','\"4\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.multiline','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.placeholder','\"\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.settings.uiMode','\"normal\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.translationKeyFormat','null'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.translationMethod','\"none\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.fields.f03239f9-af65-481a-b6b8-76e0e158244f.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.handle','\"image\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.name','\"Image\"'),('matrixBlockTypes.4427e835-20ed-496b-9469-831bb0882185.sortOrder','2'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.field','\"d974bf8d-647d-45f3-98be-0733d5e3e1ba\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.fieldUid','\"854806b9-7b9c-4bee-b636-6ffb1d144b34\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.label','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.required','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.tip','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.warning','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.0.width','100'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.fieldUid','\"505d226e-5fae-49b8-9460-b78c35449b2e\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.label','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.required','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.tip','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.warning','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.1.width','100'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.fieldUid','\"6f74be98-1b1b-470e-a96a-727b01e0b225\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.label','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.required','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.tip','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.warning','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.elements.2.width','100'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.name','\"Content\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fieldLayouts.bc2a4d96-e189-4577-9559-d25bf551d2c1.tabs.0.sortOrder','1'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.contentColumnType','\"text\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.fieldGroup','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.handle','\"sectionsubtitle\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.instructions','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.name','\"SectionSubtitle\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.searchable','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.byteLimit','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.charLimit','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.code','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.columnType','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.initialRows','\"4\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.multiline','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.placeholder','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.settings.uiMode','\"normal\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.translationKeyFormat','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.translationMethod','\"none\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.505d226e-5fae-49b8-9460-b78c35449b2e.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.contentColumnType','\"string\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.fieldGroup','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.handle','\"videoUpload\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.instructions','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.name','\"Video Upload\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.searchable','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.allowedKinds.0','\"video\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.allowSelfRelations','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.allowUploads','true'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.defaultUploadLocationSource','\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.defaultUploadLocationSubpath','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.limit','\"1\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.localizeRelations','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.previewMode','\"full\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.restrictFiles','\"1\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.selectionLabel','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.showSiteMenu','true'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.showUnpermittedFiles','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.singleUploadLocationSource','\"volume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.singleUploadLocationSubpath','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.source','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.sources.0','\"volume:d19b4314-0267-4e95-9e63-2462a334eea1\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.targetSiteId','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.useSingleFolder','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.validateRelatedElements','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.settings.viewMode','\"list\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.translationKeyFormat','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.translationMethod','\"site\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.6f74be98-1b1b-470e-a96a-727b01e0b225.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.contentColumnType','\"text\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.fieldGroup','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.handle','\"sectionTitle\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.instructions','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.name','\"Section Title\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.searchable','false'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.byteLimit','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.charLimit','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.code','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.columnType','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.initialRows','\"4\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.multiline','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.placeholder','\"\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.settings.uiMode','\"normal\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.translationKeyFormat','null'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.translationMethod','\"none\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.fields.854806b9-7b9c-4bee-b636-6ffb1d144b34.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.handle','\"video\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.name','\"Video\"'),('matrixBlockTypes.a399fb79-90a6-48a0-be1f-38d2b8a81af5.sortOrder','3'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.field','\"d974bf8d-647d-45f3-98be-0733d5e3e1ba\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.fieldUid','\"14e1bd82-34c0-42c5-a72d-1d002d9775d2\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.label','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.required','false'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.tip','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.warning','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.0.width','100'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.fieldUid','\"158c7930-10bb-483f-8328-c8aa657d8647\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.label','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.required','false'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.tip','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.warning','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.elements.1.width','100'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.name','\"Content\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fieldLayouts.2be8891e-b97f-4d20-8c96-63ee3acef638.tabs.0.sortOrder','1'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.contentColumnType','\"text\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.fieldGroup','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.handle','\"videoTitle\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.instructions','\"\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.name','\"Video Title\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.searchable','false'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.byteLimit','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.charLimit','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.code','\"\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.columnType','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.initialRows','\"4\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.multiline','\"\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.placeholder','\"\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.settings.uiMode','\"normal\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.translationKeyFormat','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.translationMethod','\"none\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.14e1bd82-34c0-42c5-a72d-1d002d9775d2.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.contentColumnType','\"text\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.fieldGroup','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.handle','\"videoId\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.instructions','\"i.e. LTRD2wUQ4KY\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.name','\"Video ID\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.searchable','false'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.byteLimit','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.charLimit','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.code','\"\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.columnType','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.initialRows','\"4\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.multiline','\"\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.placeholder','\"\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.settings.uiMode','\"normal\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.translationKeyFormat','null'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.translationMethod','\"none\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.fields.158c7930-10bb-483f-8328-c8aa657d8647.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.handle','\"youtubeVideo\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.name','\"YouTube Video\"'),('matrixBlockTypes.c4527788-b877-44f3-9a2d-071f696877fa.sortOrder','4'),('plugins.environment-label.edition','\"standard\"'),('plugins.environment-label.enabled','true'),('plugins.environment-label.schemaVersion','\"1.0.0\"'),('plugins.image-toolbox.edition','\"standard\"'),('plugins.image-toolbox.enabled','true'),('plugins.image-toolbox.schemaVersion','\"1.0.0\"'),('plugins.minify.edition','\"standard\"'),('plugins.minify.enabled','true'),('plugins.minify.schemaVersion','\"1.0.0\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('plugins.retcon.edition','\"standard\"'),('plugins.retcon.enabled','true'),('plugins.retcon.schemaVersion','\"1.0.0\"'),('plugins.seomatic.edition','\"standard\"'),('plugins.seomatic.enabled','true'),('plugins.seomatic.licenseKey','\"GAGO3GIITAF1YMQ8JZWMIUYU\"'),('plugins.seomatic.schemaVersion','\"3.0.9\"'),('plugins.templatecomments.edition','\"standard\"'),('plugins.templatecomments.enabled','true'),('plugins.templatecomments.schemaVersion','\"1.0.0\"'),('plugins.usermanual.edition','\"standard\"'),('plugins.usermanual.enabled','true'),('plugins.usermanual.schemaVersion','\"2.0.1\"'),('plugins.usermanual.settings.pluginNameOverride','\"User Manual\"'),('plugins.usermanual.settings.section','\"3\"'),('plugins.usermanual.settings.templateOverride','\"_user-guide/_entry\"'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.enableVersioning','true'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.handle','\"userGuide\"'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.name','\"User Guide\"'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.propagationMethod','\"all\"'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.enabledByDefault','true'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.hasUrls','true'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.template','\"user-guide/_entry\"'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.uriFormat','\"user-guide/{slug}\"'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.structure.maxLevels','null'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.structure.uid','\"a998bd9e-f13e-4af0-b105-e9cdf72d6151\"'),('sections.0784ad32-f952-40b1-9f6c-d0e67d502551.type','\"structure\"'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.enableVersioning','true'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.handle','\"homepage\"'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.name','\"Homepage\"'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.propagationMethod','\"all\"'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.enabledByDefault','true'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.hasUrls','true'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.template','\"homepage/_entry\"'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.siteSettings.1a78d395-d81a-4b77-8da7-30a49123bbee.uriFormat','\"homepage\"'),('sections.722083b8-e7bc-4d95-b4dd-3473680b72a7.type','\"single\"'),('siteGroups.2fcd48d2-b2b1-479f-9015-016904e4eab4.name','\"Craft Starter\"'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.handle','\"default\"'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.hasUrls','true'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.language','\"en-CA\"'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.name','\"Craft Starter\"'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.primary','true'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.siteGroup','\"2fcd48d2-b2b1-479f-9015-016904e4eab4\"'),('sites.1a78d395-d81a-4b77-8da7-30a49123bbee.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"$SITE_NAME\"'),('system.retryDuration','null'),('system.schemaVersion','\"3.6.1\"'),('system.timeZone','\"America/Toronto\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.description','\"\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.handle','\"siteAdmin\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.name','\"Site Admin\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.0','\"accessplugin-seomatic\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.1','\"accessplugin-usermanual\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.10','\"deletefilesandfoldersinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.11','\"replacefilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.12','\"editimagesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.13','\"editpeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.14','\"replacepeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.15','\"deletepeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.16','\"editpeerimagesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.17','\"viewpeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.18','\"viewvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.19','\"utility:system-report\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.2','\"accesscp\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.20','\"utility:asset-indexes\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.21','\"utility:db-backup\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.22','\"seomatic:dashboard\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.23','\"seomatic:global-meta:general\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.24','\"seomatic:global-meta:twitter\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.25','\"seomatic:global-meta:facebook\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.26','\"seomatic:global-meta:robots\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.27','\"seomatic:global-meta\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.28','\"seomatic:content-meta:general\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.29','\"seomatic:content-meta:twitter\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.3','\"publishentries:722083b8-e7bc-4d95-b4dd-3473680b72a7\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.30','\"seomatic:content-meta:facebook\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.31','\"seomatic:content-meta:sitemap\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.32','\"seomatic:content-meta\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.33','\"seomatic:site-settings:identity\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.34','\"seomatic:site-settings:social\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.35','\"seomatic:site-settings:sitemap\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.36','\"seomatic:site-settings\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.37','\"seomatic:tracking-scripts:googleanalytics\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.38','\"seomatic:tracking-scripts:gtag\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.39','\"seomatic:tracking-scripts:googletagmanager\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.4','\"publishpeerentrydrafts:722083b8-e7bc-4d95-b4dd-3473680b72a7\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.40','\"seomatic:tracking-scripts\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.5','\"deletepeerentrydrafts:722083b8-e7bc-4d95-b4dd-3473680b72a7\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.6','\"editpeerentrydrafts:722083b8-e7bc-4d95-b4dd-3473680b72a7\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.7','\"editentries:722083b8-e7bc-4d95-b4dd-3473680b72a7\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.8','\"saveassetinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.groups.0878c4de-b946-4c8e-bcce-fe18cd77a73e.permissions.9','\"createfoldersinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670\"'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.autocapitalize','true'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.autocomplete','false'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.autocorrect','true'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.class','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.disabled','false'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.id','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.instructions','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.label','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.max','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.min','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.name','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.orientation','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.placeholder','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.readonly','false'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.requirable','false'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.size','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.step','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.tip','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.title','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\AssetTitleField\"'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.warning','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.elements.0.width','100'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.name','\"Content\"'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.fieldLayouts.b06de4af-a975-4b6c-8ef4-1c794da71432.tabs.0.sortOrder','1'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.handle','\"uploads\"'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.hasUrls','true'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.name','\"Uploads\"'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.settings.path','\"$ASSET_BASE_PATH\"'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.sortOrder','1'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.titleTranslationKeyFormat','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.titleTranslationMethod','null'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.type','\"craft\\\\volumes\\\\Local\"'),('volumes.70f5d47b-4830-4d51-95fe-bc0f7ccc0670.url','\"$ASSET_BASE_URL\"'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.autocapitalize','true'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.autocomplete','false'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.autocorrect','true'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.class','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.disabled','false'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.id','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.instructions','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.label','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.max','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.min','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.name','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.orientation','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.placeholder','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.readonly','false'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.requirable','false'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.size','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.step','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.tip','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.title','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\AssetTitleField\"'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.warning','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.elements.0.width','100'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.name','\"Content\"'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.fieldLayouts.eb53ac7e-fc3b-4522-a428-91addf2ec44f.tabs.0.sortOrder','1'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.handle','\"userGuide\"'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.hasUrls','true'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.name','\"User Guide\"'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.settings.path','\"$GUIDE_BASE_PATH\"'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.sortOrder','2'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.titleTranslationKeyFormat','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.titleTranslationMethod','null'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.type','\"craft\\\\volumes\\\\Local\"'),('volumes.d19b4314-0267-4e95-9e63-2462a334eea1.url','\"$GUIDE_BASE_URL\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_fkskrlnmwzhwipjgulzhggpercotzulxkgvw` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_wgelyqbiytmdiasebsczayaoyhusvvbjjurl` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qjczvvvsmcqjjltlwvvzlujqcqolzialvebm` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_alkqietfemlmnoqnatrpqxrqdrofibiazovw` (`sourceId`),
  KEY `idx_watjsakbbyeoftwohdqkmuoprqkjivsscgvp` (`targetId`),
  KEY `idx_pqfnuawqjpbxmxpwwkyhtqxpmnvvilbkszvb` (`sourceSiteId`),
  CONSTRAINT `fk_bbrmnfpwwducsoqiwjoscikvjpoobriorthw` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ketdkvlbmfznfiiiabxeswalrtjlfozclvca` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_svlrkvdfggfvfbwefhgmdntzbwwemsbcxpny` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zucutbkoynlxwxvtczarabjjdkpkerrglxsn` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('184f4f38','@app/web/assets/pluginstore/dist'),('1e3a259e','@app/web/assets/recententries/dist'),('1fe64710','@lib/vue'),('208067f0','@app/web/assets/updateswidget/dist'),('2664159d','@craft/web/assets/plugins/dist'),('2dc344a9','@app/web/assets/fieldsettings/dist'),('2e12cb31','@app/web/assets/craftsupport/dist'),('3770213','@app/web/assets/cp/dist'),('38daa42c','@lib/jquery-ui'),('4283c8a9','@craft/web/assets/dashboard/dist'),('486c6301','@lib/element-resize-detector'),('4ba61dc2','@app/web/assets/matrixsettings/dist'),('4d5d326','@craft/web/assets/craftsupport/dist'),('5c68368e','@craft/redactor/assets/redactor-plugins/dist/video'),('5e3d252d','@craft/redactor/assets/redactor/dist'),('67fcc8f4','@bower/jquery/dist'),('6a549061','@lib/jquery.payment'),('7321f6f7','@hillholliday/usermanual/assetbundles/usermanual/dist'),('749176d','@app/web/assets/login/dist'),('76733f89','@lib/velocity'),('7fe868ab','@app/web/assets/userpermissions/dist'),('82b1014c','@app/web/assets/plugins/dist'),('888eca74','@app/web/assets/editsection/dist'),('8abbc508','@lib/timepicker'),('9a7265c9','@nystudio107/seomatic/assetbundles/seomatic/dist'),('9dc36741','@craft/web/assets/recententries/dist'),('9ebf880f','@app/web/assets/admintable/dist'),('a379252f','@craft/web/assets/updateswidget/dist'),('aa567174','@craft/web/assets/generalsettings/dist'),('b5449d7d','@lib/xregexp'),('b595f8aa','@lib/axios'),('b907fcbe','@craft/web/assets/cp/dist'),('bf28d9f7','@lib/selectize'),('c07a4c5f','@app/web/assets/dashboard/dist'),('c308179a','@lib/fabric'),('c71d6211','@app/web/assets/fields/dist'),('cb310eb4','@craft/redactor/assets/field/dist'),('d64ec3a4','@lib/garnishjs'),('e0dc8e5f','@app/web/assets/editentry/dist'),('e5f3d422','@lib/d3'),('eb56f473','@lib/picturefill'),('ecf2c8b1','@lib/jquery-touch-events'),('ee74c238','@lib/prismjs'),('effeac6b','@app/web/assets/matrix/dist'),('f3b96967','@craft/redactor/assets/redactor-plugins/dist/fullscreen'),('f3bef58d','@lib/fileupload'),('fd2d5657','@craft/web/assets/sites/dist'),('ff1dca9a','@lib/iframe-resizer');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rclnjhpaphyrvbslmzbvwcgwumuqutkzwfec` (`sourceId`,`num`),
  KEY `fk_hpryowtfrlcpuspedecrenxcxoidduezxlen` (`creatorId`),
  CONSTRAINT `fk_hpryowtfrlcpuspedecrenxcxoidduezxlen` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ovuuxgwzoeojjffzndlghicicglfbxherkfn` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,NULL),(3,9,1,1,''),(4,9,1,2,''),(5,9,1,3,''),(6,9,1,4,''),(7,9,1,5,''),(8,21,1,1,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_iecqgucfkjhopvxqycyubknrcjcdbgikeqxc` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,2,' sean caffeinecreations ca '),(1,'firstname',0,2,''),(1,'fullname',0,2,''),(1,'lastname',0,2,''),(1,'slug',0,2,''),(1,'username',0,2,' cc admin '),(2,'slug',0,2,' homepage '),(2,'title',0,2,' homepage '),(9,'slug',0,2,' general '),(9,'title',0,2,' general '),(10,'slug',0,2,''),(21,'slug',0,2,' general '),(21,'title',0,2,' general ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'all',
  `previewTargets` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cbkpvzvbvvguopjscfdfbouxfdfwjrcjamaf` (`handle`),
  KEY `idx_ekgijtccpqdawslxqqsaixjyaoebyagcbyor` (`name`),
  KEY `idx_jnkkiwbqoywygdyauoxwxisxuoyqxqsjvvas` (`structureId`),
  KEY `idx_kikzhmhjjpeusfhswndioewdftkcamxvxukw` (`dateDeleted`),
  CONSTRAINT `fk_lvyvmfvcduwghwtezdlobizhicinfuscowfw` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Homepage','homepage','single',1,'all',NULL,'2021-02-06 19:41:10','2021-02-06 19:41:10',NULL,'722083b8-e7bc-4d95-b4dd-3473680b72a7'),(2,1,'User Guide','userGuide','structure',1,'all',NULL,'2021-02-06 19:41:35','2021-02-06 19:41:35','2021-02-06 19:47:44','468c5e66-4a11-49ec-9a7f-bd43413dfeb9'),(3,2,'User Guide','userGuide','structure',1,'all',NULL,'2021-02-06 19:47:59','2021-02-06 19:47:59',NULL,'0784ad32-f952-40b1-9f6c-d0e67d502551');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8_unicode_ci,
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ybdxkomdkxrsnhnrnntrswmwkvqwmpjusbom` (`sectionId`,`siteId`),
  KEY `idx_qomysjcyuoaoiwmtaxvxpbpyaabrgrfluldr` (`siteId`),
  CONSTRAINT `fk_sycpfvfoxoatzzztiqjoukfrvpcogczwjmbn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uuxporenzmrqhgdiljvpkmbzfwcdyrfokvea` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,2,1,'homepage','homepage/_entry',1,'2021-02-06 19:41:10','2021-02-06 19:41:10','09e42d4e-b954-44e0-9163-03bf12a3533d'),(2,2,2,1,'user-guide/{slug}','user-guide/_entry',1,'2021-02-06 19:41:35','2021-02-06 19:41:35','81daa230-fa2c-4a1a-a1e8-1dd633c26b2a'),(3,3,2,1,'user-guide/{slug}','user-guide/_entry',1,'2021-02-06 19:47:59','2021-02-06 19:47:59','20f6f007-db23-4e31-b604-f37e09c25fd7');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seomatic_metabundles`
--

DROP TABLE IF EXISTS `seomatic_metabundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seomatic_metabundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `bundleVersion` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceBundleType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceId` int(11) DEFAULT NULL,
  `sourceName` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceHandle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceType` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `typeId` int(11) DEFAULT NULL,
  `sourceTemplate` varchar(500) COLLATE utf8_unicode_ci DEFAULT '',
  `sourceSiteId` int(11) DEFAULT NULL,
  `sourceAltSiteSettings` text COLLATE utf8_unicode_ci,
  `sourceDateUpdated` datetime NOT NULL,
  `metaGlobalVars` text COLLATE utf8_unicode_ci,
  `metaSiteVars` text COLLATE utf8_unicode_ci,
  `metaSitemapVars` text COLLATE utf8_unicode_ci,
  `metaContainers` text COLLATE utf8_unicode_ci,
  `redirectsContainer` text COLLATE utf8_unicode_ci,
  `frontendTemplatesContainer` text COLLATE utf8_unicode_ci,
  `metaBundleSettings` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_ctewkogxtzemmotrnegqvlpaubmautkepsrx` (`sourceBundleType`),
  KEY `idx_csksrfrgztaatxsdumyapgyimtonzgiampav` (`sourceId`),
  KEY `idx_ugssskkhqnlodgzqrpjxfzoafrvgzcfsunhb` (`sourceSiteId`),
  KEY `idx_yqlijnffkanuwndrcadwjednnjwfugedtamb` (`sourceHandle`),
  CONSTRAINT `fk_buerkengveyjpwbxypgrgmlmrhkyokfuektw` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seomatic_metabundles`
--

LOCK TABLES `seomatic_metabundles` WRITE;
/*!40000 ALTER TABLE `seomatic_metabundles` DISABLE KEYS */;
INSERT INTO `seomatic_metabundles` VALUES (1,'2021-02-06 19:29:00','2021-02-06 19:29:00','01db7cd2-0005-4da8-849e-cf7f39db8087','1.0.47','__GLOBAL_BUNDLE__',1,'__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__',NULL,'',1,'[]','2021-02-06 19:29:00','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"before\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{seomatic.helper.safeCanonicalUrl()}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"Craft Starter\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]}},\"keywords\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoKeywords}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null},\"description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoDescription}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null},\"referrer\":{\"charset\":\"\",\"content\":\"{seomatic.site.referrer}\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null},\"robots\":{\"charset\":\"\",\"content\":\"{seomatic.meta.robots}\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{seomatic.meta.robots}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookProfileId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookAppId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null},\"og:site_name\":{\"charset\":\"\",\"content\":\"{seomatic.site.siteName}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null},\"og:type\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogType}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null},\"og:url\":{\"charset\":\"\",\"content\":\"{seomatic.meta.canonicalUrl}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null},\"og:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.ogSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.ogTitle}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null},\"og:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null},\"og:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImage}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null},\"og:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageWidth}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageHeight}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterCard}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{seomatic.site.twitterHandle}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]}},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{seomatic.meta.twitterCreator}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]}},\"twitter:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.twitterSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.twitterTitle}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null},\"twitter:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null},\"twitter:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImage}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageWidth}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageHeight}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.googleSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]}},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.bingSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]}},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.pinterestSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]}}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{seomatic.meta.canonicalUrl}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]}},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{seomatic.site.googlePublisherLink}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]}}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"googleAnalytics\":{\"name\":\"Google Analytics\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https://www.google.com/analytics/analytics/)\",\"templatePath\":\"_frontend/scripts/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.google-analytics.com/analytics.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https://developers.google.com/gtagjs/)\",\"templatePath\":\"_frontend/scripts/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https://developers.google.com/adwords-remarketing-tag/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https://support.google.com/dcm/partner/answer/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtag/js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https://support.google.com/tagmanager/answer/6102821?hl=en)\",\"templatePath\":\"_frontend/scripts/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"></iframe></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https://developers.google.com/tag-manager/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dataLayer\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/ns.html\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https://www.facebook.com/business/help/651294705016616)\",\"templatePath\":\"_frontend/scripts/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" /></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://developers.facebook.com/docs/facebook-pixel/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://connect.facebook.net/en_US/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.facebook.com/tr\"}},\"dataLayer\":[],\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend/scripts/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n</script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" />\\n</noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://www.linkedin.com/help/lms/answer/65513/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://snap.licdn.com/li.lms-analytics/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://dc.ads.linkedin.com/collect/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://knowledge.hubspot.com/articles/kcs_article/reports/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"//js.hs-scripts.com/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"issn\":null,\"about\":null,\"abstract\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"acquireLicensePage\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"conditionsOfAccess\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":null,\"correction\":null,\"creativeWorkStatus\":null,\"creator\":{\"id\":\"{seomatic.site.creator.genericUrl}#creator\"},\"dateCreated\":null,\"dateModified\":null,\"datePublished\":null,\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":null,\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"maintainer\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":null,\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"usageInfo\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"nonce\":null},\"identity\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.identity.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.identity.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.identity.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.identity.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.identity.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.identity.organizationDuns}\",\"email\":\"{seomatic.site.identity.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.identity.organizationFounder}\",\"foundingDate\":\"{seomatic.site.identity.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.identity.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasCredential\":null,\"hasMerchantReturnPolicy\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"interactionStatistic\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.identity.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.identity.genericAlternateName}\",\"description\":\"{seomatic.site.identity.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.identity.genericImage}\",\"width\":\"{seomatic.site.identity.genericImageWidth}\",\"height\":\"{seomatic.site.identity.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.identity.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.identity.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.identity.computedType}\",\"id\":\"{seomatic.site.identity.genericUrl}#identity\",\"graph\":null,\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null,\"nonce\":null},\"creator\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.creator.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.creator.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.creator.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.creator.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.creator.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.creator.organizationDuns}\",\"email\":\"{seomatic.site.creator.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.creator.organizationFounder}\",\"foundingDate\":\"{seomatic.site.creator.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.creator.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasCredential\":null,\"hasMerchantReturnPolicy\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"interactionStatistic\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.creator.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.creator.genericAlternateName}\",\"description\":\"{seomatic.site.creator.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.creator.genericImage}\",\"width\":\"{seomatic.site.creator.genericImageWidth}\",\"height\":\"{seomatic.site.creator.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.creator.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.creator.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.creator.computedType}\",\"id\":\"{seomatic.site.creator.genericUrl}#creator\",\"graph\":null,\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null,\"nonce\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"/* TEAM */\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n/a\\\" }}\\nURL: {{ seomatic.site.creator.genericUrl ?? \\\"n/a\\\" }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n/a\\\" }}\\n\\n/* THANKS */\\n\\nCraft CMS - https://craftcms.com\\nPixel & Tonic - https://pixelandtonic.com\\n\\n/* SITE */\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 3, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend/pages/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ siteUrl }}\\n\\nSitemap: {{ seomatic.helper.sitemapIndexForSiteId() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n# live - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% case \\\"staging\\\" %}\\n\\n# staging - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% case \\\"local\\\" %}\\n\\n# local - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% default %}\\n\\n# default - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% endswitch %}\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend/pages/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ siteUrl }}\\n# More info: https://support.google.com/admanager/answer/7441288?hl=en\\n{{ siteUrl }},123,DIRECT\\n\",\"siteId\":null,\"include\":true,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend/pages/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(2,'2021-02-06 19:33:13','2021-02-06 19:33:13','d9cf05a2-6238-4d13-b8ed-aae73a5073c8','1.0.47','__GLOBAL_BUNDLE__',1,'__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__',NULL,'',2,'[]','2021-02-06 19:33:13','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"before\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{seomatic.helper.safeCanonicalUrl()}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]}},\"keywords\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoKeywords}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null},\"description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoDescription}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null},\"referrer\":{\"charset\":\"\",\"content\":\"{seomatic.site.referrer}\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null},\"robots\":{\"charset\":\"\",\"content\":\"{seomatic.meta.robots}\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{seomatic.meta.robots}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookProfileId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookAppId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null},\"og:site_name\":{\"charset\":\"\",\"content\":\"{seomatic.site.siteName}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null},\"og:type\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogType}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null},\"og:url\":{\"charset\":\"\",\"content\":\"{seomatic.meta.canonicalUrl}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null},\"og:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.ogSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.ogTitle}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null},\"og:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null},\"og:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImage}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null},\"og:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageWidth}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageHeight}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterCard}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{seomatic.site.twitterHandle}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]}},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{seomatic.meta.twitterCreator}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]}},\"twitter:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.twitterSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.twitterTitle}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null},\"twitter:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null},\"twitter:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImage}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageWidth}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageHeight}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.googleSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]}},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.bingSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]}},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.pinterestSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]}}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{seomatic.meta.canonicalUrl}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]}},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{seomatic.site.googlePublisherLink}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]}}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"googleAnalytics\":{\"name\":\"Google Analytics\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https://www.google.com/analytics/analytics/)\",\"templatePath\":\"_frontend/scripts/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.google-analytics.com/analytics.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https://developers.google.com/gtagjs/)\",\"templatePath\":\"_frontend/scripts/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https://developers.google.com/adwords-remarketing-tag/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https://support.google.com/dcm/partner/answer/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtag/js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https://support.google.com/tagmanager/answer/6102821?hl=en)\",\"templatePath\":\"_frontend/scripts/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"></iframe></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https://developers.google.com/tag-manager/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dataLayer\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/ns.html\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https://www.facebook.com/business/help/651294705016616)\",\"templatePath\":\"_frontend/scripts/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" /></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://developers.facebook.com/docs/facebook-pixel/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://connect.facebook.net/en_US/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.facebook.com/tr\"}},\"dataLayer\":[],\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend/scripts/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n</script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" />\\n</noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://www.linkedin.com/help/lms/answer/65513/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://snap.licdn.com/li.lms-analytics/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://dc.ads.linkedin.com/collect/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://knowledge.hubspot.com/articles/kcs_article/reports/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"//js.hs-scripts.com/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"nonce\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"issn\":null,\"about\":null,\"abstract\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"acquireLicensePage\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"conditionsOfAccess\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":null,\"correction\":null,\"creativeWorkStatus\":null,\"creator\":{\"id\":\"{seomatic.site.creator.genericUrl}#creator\"},\"dateCreated\":null,\"dateModified\":null,\"datePublished\":null,\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":null,\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"maintainer\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":null,\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"usageInfo\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"nonce\":null},\"identity\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.identity.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.identity.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.identity.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.identity.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.identity.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.identity.organizationDuns}\",\"email\":\"{seomatic.site.identity.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.identity.organizationFounder}\",\"foundingDate\":\"{seomatic.site.identity.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.identity.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasCredential\":null,\"hasMerchantReturnPolicy\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"interactionStatistic\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.identity.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.identity.genericAlternateName}\",\"description\":\"{seomatic.site.identity.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.identity.genericImage}\",\"width\":\"{seomatic.site.identity.genericImageWidth}\",\"height\":\"{seomatic.site.identity.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.identity.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.identity.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.identity.computedType}\",\"id\":\"{seomatic.site.identity.genericUrl}#identity\",\"graph\":null,\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null,\"nonce\":null},\"creator\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.creator.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.creator.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.creator.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.creator.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.creator.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.creator.organizationDuns}\",\"email\":\"{seomatic.site.creator.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.creator.organizationFounder}\",\"foundingDate\":\"{seomatic.site.creator.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.creator.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasCredential\":null,\"hasMerchantReturnPolicy\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"interactionStatistic\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.creator.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.creator.genericAlternateName}\",\"description\":\"{seomatic.site.creator.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.creator.genericImage}\",\"width\":\"{seomatic.site.creator.genericImageWidth}\",\"height\":\"{seomatic.site.creator.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.creator.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.creator.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.creator.computedType}\",\"id\":\"{seomatic.site.creator.genericUrl}#creator\",\"graph\":null,\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null,\"nonce\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"/* TEAM */\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n/a\\\" }}\\nURL: {{ seomatic.site.creator.genericUrl ?? \\\"n/a\\\" }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n/a\\\" }}\\n\\n/* THANKS */\\n\\nCraft CMS - https://craftcms.com\\nPixel & Tonic - https://pixelandtonic.com\\n\\n/* SITE */\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 3, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend/pages/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ siteUrl }}\\n\\nSitemap: {{ seomatic.helper.sitemapIndexForSiteId() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n# live - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% case \\\"staging\\\" %}\\n\\n# staging - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% case \\\"local\\\" %}\\n\\n# local - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% default %}\\n\\n# default - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% endswitch %}\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend/pages/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ siteUrl }}\\n# More info: https://support.google.com/admanager/answer/7441288?hl=en\\n{{ siteUrl }},123,DIRECT\\n\",\"siteId\":null,\"include\":true,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend/pages/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(3,'2021-02-06 19:41:10','2021-02-06 19:41:19','be77f524-f328-4310-b883-2ab20fac272f','1.0.28','section',1,'Homepage','homepage','single',NULL,'homepage/_entry',2,'{\"2\":{\"id\":1,\"sectionId\":1,\"siteId\":2,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"homepage\",\"template\":\"homepage/_entry\",\"language\":\"en-ca\"}}','2021-02-06 19:41:18','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{entry.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"abstract\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"acquireLicensePage\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"conditionsOfAccess\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate | date(\\\"Y\\\")}\",\"correction\":null,\"creativeWorkStatus\":null,\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"maintainer\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"usageInfo\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"nonce\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(5,'2021-02-06 19:47:59','2021-02-06 19:48:37','623e9ac7-d0fa-4771-894d-00c7b0a22540','1.0.28','section',3,'User Guide','userGuide','structure',NULL,'user-guide/_entry',2,'{\"2\":{\"id\":3,\"sectionId\":3,\"siteId\":2,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"user-guide/{slug}\",\"template\":\"user-guide/_entry\",\"language\":\"en-ca\"}}','2021-02-06 19:48:37','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{entry.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"abstract\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"acquireLicensePage\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"conditionsOfAccess\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate | date(\\\"Y\\\")}\",\"correction\":null,\"creativeWorkStatus\":null,\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"maintainer\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"usageInfo\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"nonce\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
/*!40000 ALTER TABLE `seomatic_metabundles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wunbdkcmqznvyxfcmfgqsbrbthiogcebetds` (`uid`),
  KEY `idx_zznxylwrowwxneatgsgkaqmhhlzqtepbphbq` (`token`),
  KEY `idx_pfrmmsvqppajpicbwfvpfjsaoepeukhigmqh` (`dateUpdated`),
  KEY `idx_owwfozwyjvmczjnxqxgvdebuoegnzijpityj` (`userId`),
  CONSTRAINT `fk_gfcgauuftfljczejyfontycgcjcvkrendmrj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'aN5V9z8tXfd1KJp4chN3PX8XtU4aNj4MpvmNxh9L6-FxvbDDD92890ESVg5vYOEXvW_AHeUVnHSPSH296IAupyChvOcyKYLn6pMh','2021-02-06 19:29:01','2021-02-06 19:37:00','4e5fa3f6-44dd-4f95-bfac-6a37e5cea69c'),(2,1,'lNbO1HaJAWkD8rxk-MuLDFgb6upguNt4NkWpCcYiZBr1tYoTLLinmqWZvAXH99GKDR10qnm8n9nKF7tRpKFCYbCowhQSdJ69Iysn','2021-02-13 13:33:26','2021-02-13 13:56:44','44714285-b446-4f9c-97c7-90b75438380b'),(3,1,'sUhIaNfxegiOPtCtocwVn_34VKz-mClPSI-spn_2D9uVcSDkhsLVMnqaj0C1UAyH3h1AZgeVWhq13FIcGkjA7oQamrSLtvCfukHm','2021-02-20 17:48:51','2021-02-20 18:00:35','3cbb407b-bb96-4bd0-b354-9ab61d35a33f');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cmeppiksqoqcwstrcnvoobngwofyiippjpvt` (`userId`,`message`),
  CONSTRAINT `fk_kedhoppicevuocnrdunqthntihnxspvtirff` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tyjijuxmgzgrgcdxkwemjpijevzuoflyyquq` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Craft Starter','2021-02-06 19:29:00','2021-02-06 19:30:24','2021-02-06 19:30:24','38bc3eca-9628-4f0a-ad87-28a75a4e315b'),(2,'Craft Starter','2021-02-06 19:29:00','2021-02-06 19:29:00',NULL,'2fcd48d2-b2b1-479f-9015-016904e4eab4');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gaqiaimkcdjhdvhggiilarfiweleefynqnpp` (`dateDeleted`),
  KEY `idx_pfedgqqrbvgkkptlstjsrrhvgvrdmidrgckp` (`handle`),
  KEY `idx_xbgzpxvxqygcorlyltsduxrqietncogfrnae` (`sortOrder`),
  KEY `fk_alxxlhhlxpdlxfpfgqcobcisxkcvkcuaiwod` (`groupId`),
  CONSTRAINT `fk_alxxlhhlxpdlxfpfgqcobcisxkcvkcuaiwod` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,0,1,'Craft Starter','default','en-CA',1,'$PRIMARY_SITE_URL',1,'2021-02-06 19:29:00','2021-02-06 19:29:00','2021-02-06 19:30:16','74c55cb7-9b6e-413c-b49a-72007dc3f204'),(2,2,1,1,'Craft Starter','default','en-CA',1,'$PRIMARY_SITE_URL',1,'2021-02-06 19:29:00','2021-02-06 19:29:00',NULL,'1a78d395-d81a-4b77-8da7-30a49123bbee');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wqhgftykcndpeeveytelpzjxcmmzigbbrwlb` (`structureId`,`elementId`),
  KEY `idx_ypkrjirjlvrdaovmukflgxyrouusxkrspvde` (`root`),
  KEY `idx_fajczhhmticocmlgvdskyahfexreueuqqewg` (`lft`),
  KEY `idx_bodpbptdcnggezznatmvkfdyhowushziqtua` (`rgt`),
  KEY `idx_osknwnkjluuwtbltjljyalcedlhxlywkggyc` (`level`),
  KEY `idx_idpfsiupbmuyslzaswhsbaptmjevshdtqvfg` (`elementId`),
  CONSTRAINT `fk_pqaxlkvjnpgnqqabsxxrepqvbiviqaefpkwg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wtdinzjffeqkqcpbpajpbwvhwocvqdcvajex` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,12,0,'2021-02-06 19:42:09','2021-02-06 19:47:44','33511825-c3a2-4721-bbbd-6c7b58bce966'),(4,1,11,1,10,11,1,'2021-02-06 19:42:27','2021-02-06 19:47:44','7ab31356-ac30-48c2-ab50-07c06142f7a6'),(5,1,13,1,8,9,1,'2021-02-06 19:42:53','2021-02-06 19:47:44','055c2c5b-3781-4f10-91d8-1e2d917b2e47'),(6,1,15,1,6,7,1,'2021-02-06 19:45:15','2021-02-06 19:47:44','ec3fcbfd-2151-4b10-93e6-1a54d62059ce'),(7,1,17,1,4,5,1,'2021-02-06 19:45:18','2021-02-06 19:47:44','90847fcb-15fb-4cf8-a90b-f4a16380e1ef'),(8,1,19,1,2,3,1,'2021-02-06 19:47:31','2021-02-06 19:47:44','cada8909-9101-4cad-91d9-761c62e4f00a'),(9,2,NULL,9,1,6,0,'2021-02-06 19:48:22','2021-02-06 19:48:37','006f350c-5129-47d6-b73e-e14ebad744cd'),(11,2,21,9,2,3,1,'2021-02-06 19:48:37','2021-02-06 19:48:37','a13cdf2b-8bff-4701-9612-7a0e6518199d'),(12,2,22,9,4,5,1,'2021-02-06 19:48:37','2021-02-06 19:48:37','87c88516-cb2a-4976-8db5-3713f321ca9b');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_flbagydhzcvxsqxlasdpxgtooytyydofghjb` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,NULL,'2021-02-06 19:41:35','2021-02-06 19:41:35','2021-02-06 19:47:44','92c738ab-19b2-4eed-8133-9b99a302757e'),(2,NULL,'2021-02-06 19:47:59','2021-02-06 19:47:59',NULL,'a998bd9e-f13e-4af0-b105-e9cdf72d6151');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_giyaxmfptlcxmunyzyzhkyfkmlsjoivvzhoq` (`key`,`language`),
  KEY `idx_aeyrjcbmgexaumkbvdgioryctwwwhrzlyzrb` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nnnfatybuktdnaacsiuasxllpmwagtdqxevx` (`name`),
  KEY `idx_uqdpwffvcyfopxnyyegetrsgmzlvfgxfjzyn` (`handle`),
  KEY `idx_dyanjmhjblvfcwmdbipyanowswiwveuvdzxj` (`dateDeleted`),
  KEY `fk_apwxdvbaxsrsnxbxtjbgovimfkvhwuxbpfir` (`fieldLayoutId`),
  CONSTRAINT `fk_apwxdvbaxsrsnxbxtjbgovimfkvhwuxbpfir` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_anhlojrwvehjjlmkoptouvffnhhtvvwlpjaa` (`groupId`),
  CONSTRAINT `fk_arapuenlinvygzoogqsyvvaclptokyilitve` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tfgmxkdynllqwnkpikfrkbehigwhrepyzhqv` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templatecacheelements`
--

DROP TABLE IF EXISTS `templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecacheelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_iphebtwrgtkacggmpfblpgchfseohrjvdkzp` (`cacheId`),
  KEY `idx_fqypnkrfinvezemewvhrqowtwxmtowjuqpdd` (`elementId`),
  CONSTRAINT `fk_ozkbjtlzbpnyfcspxxnxxzjynalyedhapigz` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pejfljtgpzbcdexcejtzkmlogzzwcetkqtsx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templatecacheelements`
--

LOCK TABLES `templatecacheelements` WRITE;
/*!40000 ALTER TABLE `templatecacheelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `templatecacheelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templatecachequeries`
--

DROP TABLE IF EXISTS `templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aszzzhujekgjhnlnsgajdyuxrpnfghribryn` (`cacheId`),
  KEY `idx_nqchucagemkvncbprlqezrvcylnucqzwynts` (`type`),
  CONSTRAINT `fk_rpumjotwvmcilnegleuojaveheujspggdxar` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templatecachequeries`
--

LOCK TABLES `templatecachequeries` WRITE;
/*!40000 ALTER TABLE `templatecachequeries` DISABLE KEYS */;
/*!40000 ALTER TABLE `templatecachequeries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templatecaches`
--

DROP TABLE IF EXISTS `templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fwkkznxujanzmeofqbxhqzclxvbfqlqpkpeu` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `idx_kyvqltyftacgemdaoolrqcaxaljhatfdnmik` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `idx_frmodiykqxrgurvpyuysnmxrqrgbqapsqlkg` (`siteId`),
  CONSTRAINT `fk_ejmevzvucptlwtcadgspmklamzfriaifudgv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templatecaches`
--

LOCK TABLES `templatecaches` WRITE;
/*!40000 ALTER TABLE `templatecaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `templatecaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `route` text COLLATE utf8_unicode_ci,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dyzbbwpaqxlnxbzeoospogidqtihwrbynljy` (`token`),
  KEY `idx_dvxbllsaojbhahicegkhwglhfroxksoogsfw` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mbptwvlznzoisvjkvzctkhqgzzdizoukbyze` (`handle`),
  KEY `idx_ufrbqxcstwbypocabxeosgzbggokunljxvho` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
INSERT INTO `usergroups` VALUES (1,'Site Admin','siteAdmin','','2021-02-06 19:52:46','2021-02-06 19:52:46','0878c4de-b946-4c8e-bcce-fe18cd77a73e');
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ckqdfiivrrhykvwsspltqpqwdgyktvfcmzck` (`groupId`,`userId`),
  KEY `idx_kyczoguesqgmliuriklsnzqgwkwoksevphzs` (`userId`),
  CONSTRAINT `fk_levsosufadumjiikqcemfobxyhewqsvvapyt` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_skhnmdyqapmsagzjslhignsxqhqfgippmcyz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zlndlobvzanrjdhvspebzyhzjvlpcgxpkqmo` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
INSERT INTO `userpermissions` VALUES (1,'accessplugin-seomatic','2021-02-06 19:52:46','2021-02-06 19:52:46','647d8baf-8117-4f93-97b5-5d5fced326ae'),(2,'accessplugin-usermanual','2021-02-06 19:52:46','2021-02-06 19:52:46','5f7f3b94-5e60-414a-a4ee-d27cef307066'),(3,'accesscp','2021-02-06 19:52:46','2021-02-06 19:52:46','1b8f9640-73c2-4d0b-9237-417ca3456e90'),(4,'publishentries:722083b8-e7bc-4d95-b4dd-3473680b72a7','2021-02-06 19:52:46','2021-02-06 19:52:46','741ed732-2345-48d8-905c-291772b99638'),(5,'publishpeerentrydrafts:722083b8-e7bc-4d95-b4dd-3473680b72a7','2021-02-06 19:52:46','2021-02-06 19:52:46','7e0b70a3-92aa-41cb-8557-ba4a9d47d75b'),(6,'deletepeerentrydrafts:722083b8-e7bc-4d95-b4dd-3473680b72a7','2021-02-06 19:52:46','2021-02-06 19:52:46','9a469dfe-a8db-43e6-bf53-77c4c1a8e3a0'),(7,'editpeerentrydrafts:722083b8-e7bc-4d95-b4dd-3473680b72a7','2021-02-06 19:52:46','2021-02-06 19:52:46','7d8441c7-ab6a-4954-9d51-dcda4dd5e5fe'),(8,'editentries:722083b8-e7bc-4d95-b4dd-3473680b72a7','2021-02-06 19:52:46','2021-02-06 19:52:46','ddfda8e8-c506-44f1-9ecd-3d7143bf97b7'),(9,'saveassetinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','6b5489e5-49be-4a26-a773-78577b699eef'),(10,'createfoldersinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','42852218-8533-4ec4-aca7-4bbe94179c7a'),(11,'deletefilesandfoldersinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','3e8a3231-43f2-4b77-ac3f-27cc542b4ba2'),(12,'replacefilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','ec4c1220-23b4-42dc-9077-5b6d0f913c41'),(13,'editimagesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','22b5c20f-9c1c-4e1c-aba4-94d790f6d45d'),(14,'editpeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','b4c681cd-b5cd-49f6-82b9-579bf7e02703'),(15,'replacepeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','91ddb236-2b9c-4211-bd90-d325a51ec6db'),(16,'deletepeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','a5f489e2-d871-4652-bfe3-25f307121330'),(17,'editpeerimagesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','3b4f782e-9cc2-4fc1-98a2-8a494014936d'),(18,'viewpeerfilesinvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','24973597-56a8-44dc-b6d9-f26f51609c7d'),(19,'viewvolume:70f5d47b-4830-4d51-95fe-bc0f7ccc0670','2021-02-06 19:52:46','2021-02-06 19:52:46','4a11281b-0be7-475f-b19e-acd9f94839db'),(20,'utility:system-report','2021-02-06 19:52:46','2021-02-06 19:52:46','f6aa5c5d-8d07-4d4a-8b0d-4f098ac5e8c0'),(21,'utility:asset-indexes','2021-02-06 19:52:46','2021-02-06 19:52:46','b015be00-d5b3-4ec0-be20-552e0ad363d9'),(22,'utility:db-backup','2021-02-06 19:52:46','2021-02-06 19:52:46','25aa33d3-efc8-408a-92be-153b643a9d10'),(23,'seomatic:dashboard','2021-02-06 19:52:46','2021-02-06 19:52:46','dccd34af-a1c4-4e05-a95b-d4cdf9fc80eb'),(24,'seomatic:global-meta:general','2021-02-06 19:52:46','2021-02-06 19:52:46','27cfbabb-d2df-4e43-ad03-25dc2ca9aaff'),(25,'seomatic:global-meta:twitter','2021-02-06 19:52:46','2021-02-06 19:52:46','ba3c7fa1-504a-4acf-af16-336dd69e0623'),(26,'seomatic:global-meta:facebook','2021-02-06 19:52:46','2021-02-06 19:52:46','3104cd28-a3d1-454c-a632-160fc36d8b99'),(27,'seomatic:global-meta:robots','2021-02-06 19:52:46','2021-02-06 19:52:46','f80bd17b-da79-41b3-9fe3-86a01d6a7c46'),(28,'seomatic:global-meta','2021-02-06 19:52:46','2021-02-06 19:52:46','d071e307-98e9-496c-88e9-b18da8e5b88f'),(29,'seomatic:content-meta:general','2021-02-06 19:52:46','2021-02-06 19:52:46','b4593684-0f13-46f1-baa3-e7717f371c55'),(30,'seomatic:content-meta:twitter','2021-02-06 19:52:46','2021-02-06 19:52:46','b68a9bbb-5ac9-48df-85f2-13118321b8f4'),(31,'seomatic:content-meta:facebook','2021-02-06 19:52:46','2021-02-06 19:52:46','2c806f3e-4f73-494c-ba42-43ad9f1f44c3'),(32,'seomatic:content-meta:sitemap','2021-02-06 19:52:46','2021-02-06 19:52:46','d7ce390d-28f9-43ab-abae-b1a402d0c6c0'),(33,'seomatic:content-meta','2021-02-06 19:52:46','2021-02-06 19:52:46','9533fbe8-aeb6-443b-b902-0143d15d28d9'),(34,'seomatic:site-settings:identity','2021-02-06 19:52:46','2021-02-06 19:52:46','ec96a931-ec01-4e44-8b70-4311f65551e9'),(35,'seomatic:site-settings:social','2021-02-06 19:52:46','2021-02-06 19:52:46','907bc854-21f2-4dc8-befa-df1d7fb6b385'),(36,'seomatic:site-settings:sitemap','2021-02-06 19:52:46','2021-02-06 19:52:46','11d277c2-7c76-45ea-9139-37eb0a1c7eae'),(37,'seomatic:site-settings','2021-02-06 19:52:46','2021-02-06 19:52:46','0a6c9d7e-dabd-4750-94ea-63b9a672f902'),(38,'seomatic:tracking-scripts:googleanalytics','2021-02-06 19:52:46','2021-02-06 19:52:46','1d44989c-8e4b-4cea-843e-bc731d0198c2'),(39,'seomatic:tracking-scripts:gtag','2021-02-06 19:52:46','2021-02-06 19:52:46','1c9a4e46-6e82-4d22-9017-2b050294e6a6'),(40,'seomatic:tracking-scripts:googletagmanager','2021-02-06 19:52:46','2021-02-06 19:52:46','d6996f35-0066-4b8e-b8ec-ae159ead5933'),(41,'seomatic:tracking-scripts','2021-02-06 19:52:46','2021-02-06 19:52:46','840ade47-217e-4a73-9c26-892859de9fb8');
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wxloogvqfhpusxikhkihhdxvlwpjfyxjgpxy` (`permissionId`,`groupId`),
  KEY `idx_ijiswuwjqolgsrrbulrprshpwxuvyerjgyef` (`groupId`),
  CONSTRAINT `fk_foodvkwygdqhheevohgrcqdjdgvmwuxpqkcf` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gcwctojzkovqemrlrgjdxttwwuuuyymsoapt` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
INSERT INTO `userpermissions_usergroups` VALUES (1,1,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','156c1563-97fb-4859-8003-a95e49276f9c'),(2,2,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','42ae2433-97b9-4652-9716-f747811ae618'),(3,3,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','9f5be7d7-2dc4-4149-bf6f-4060c8161eaf'),(4,4,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','9270c445-7b2e-4a5d-a06c-a2b0f53f0f74'),(5,5,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','5be4b7bd-d029-4484-985e-c2bf594d8043'),(6,6,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','eb960c87-8511-43e2-b09a-8bf182c8bc39'),(7,7,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','15857336-4c84-49e1-9dc2-0b220ca58d8a'),(8,8,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','d4adfae8-b2a2-4e45-b218-fc0f5119d0c7'),(9,9,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','33c23579-fd64-4277-889c-458698abcb28'),(10,10,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','34a183fc-5c68-4dd5-b165-da06d8bcc712'),(11,11,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','1199573a-213d-4b87-b483-7ff5a743a575'),(12,12,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','c174450a-9ad3-4969-b622-63f035f6a3ca'),(13,13,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','c50fe21b-44b8-4e7f-923a-bf4548d8698c'),(14,14,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','09f85b1b-2c23-4a97-a8c4-88c5ddca7cb7'),(15,15,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','5b600e40-7323-45ef-af55-64a6cb15988b'),(16,16,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','4099f49c-f585-46be-8782-ad6c94dfa21a'),(17,17,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','8344124d-2392-488b-b285-188895b5119c'),(18,18,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','57471bc6-c708-4e36-a0e9-651ae4dc96c1'),(19,19,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','20fa70b4-bb19-4350-9150-ebab82b0e741'),(20,20,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','837f0928-fa53-42ea-8a84-378df2ad63a7'),(21,21,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','20193bdf-6505-4c89-9b37-7cb56f1ddb59'),(22,22,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','ba6da7ec-d8ea-4fe3-9917-841f56005d63'),(23,23,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','72a6a649-b276-4460-ad30-d6175c305c9f'),(24,24,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','70104c65-ec1e-49c5-934c-97beaa8dc997'),(25,25,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','e5606ce6-aba9-447b-a3fe-60250d162a4e'),(26,26,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','00813647-d2fc-4338-8b26-1916498588c6'),(27,27,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','93908199-ea90-4aab-b565-3651ce5cc8f6'),(28,28,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','06f5bc95-1035-47c4-9313-1166e65d8963'),(29,29,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','1050e87e-a744-4524-9c23-f693f9407cfb'),(30,30,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','89873c92-9881-469d-ac8e-fa006d7bc166'),(31,31,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','5b92ce01-b31c-4f26-a302-1d89427b819b'),(32,32,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','e818dddb-4c39-4dc0-a3a5-0654204fd126'),(33,33,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','868763de-23de-45a2-b8a0-a9a6518a4f11'),(34,34,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','9d750c88-83ba-48ea-bf7f-23500b1d7b9c'),(35,35,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','5442edac-6a0f-4971-bbab-487b17492de3'),(36,36,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','e281738c-62f9-449b-aacd-f876140e9966'),(37,37,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','b4483f48-06da-4342-8cab-9b598946e232'),(38,38,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','792b6956-9901-4be4-b4da-7c65e4ff782e'),(39,39,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','6bc8cdd2-c097-4f3d-a51a-4cb828ea038c'),(40,40,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','793a4a9f-062a-4368-9103-9d642e1c7820'),(41,41,1,'2021-02-06 19:52:46','2021-02-06 19:52:46','9c108ed9-bb9d-4572-9949-f5279f89c361');
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vdbbgsitiiwikocvdpcjikjekpgdhbbesrqp` (`permissionId`,`userId`),
  KEY `idx_cnnbskisbyvuiczlolihulehbbgbipnaucrx` (`userId`),
  CONSTRAINT `fk_erykraqqqwqdsqpbgpjonpwgucmbyaaxfika` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ykqmtejabebyvwkjqilqgdendkzzttavvqzn` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_dmutcazrqzpgrinrafmtdbxgmemyrxhhuxwn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-CA\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eglggltuziahzqdfowylwyxromubvxsjqthy` (`uid`),
  KEY `idx_qxxdgkbrsioodkfkqqtgjgcbmqnembwldxwb` (`verificationCode`),
  KEY `idx_kzharqboshyzwctbbmtsmyqhjgjtygpbfazp` (`email`),
  KEY `idx_pfhigsbervzmkqtinwdpgowekxuhnxnhsave` (`username`),
  KEY `fk_hipmvlwjiauikjgrlwfpqotnwmktesouqdow` (`photoId`),
  CONSTRAINT `fk_hipmvlwjiauikjgrlwfpqotnwmktesouqdow` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zxpzdlyagtvgiioaxalxajlymtswjgmgcfry` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'cc_admin',NULL,NULL,NULL,'sean@caffeinecreations.ca','$2y$13$8VfToRc7qHlOcSVxTfmbxO458WGJPw9GiaQzEJH6qIsxk2F88mw3C',1,0,0,0,'2021-02-20 17:48:51',NULL,NULL,NULL,'2021-02-20 17:48:45',NULL,1,NULL,NULL,NULL,0,'2021-02-06 19:29:01','2021-02-06 19:29:01','2021-02-20 17:48:51','59b3615e-d5ea-463a-9333-9bb2f8a0e81c');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qzxljggvjlchhofwvngzwzclblpxqivprewn` (`name`,`parentId`,`volumeId`),
  KEY `idx_bwvdtyrzcacalvbsrewpulsbuuvfaszjpwur` (`parentId`),
  KEY `idx_zzgvjmwjnjnlbinvbcrjioxwrqfyisyvzspq` (`volumeId`),
  CONSTRAINT `fk_jxlvafuthnuyabiemgkuufamodzrivyxhpmp` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tvzetifsbqbfkobzsdejefugristpmgdbqco` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Uploads','','2021-02-06 19:34:44','2021-02-06 19:34:44','f8d9bc26-3c3a-4958-bc17-14e0442f6480'),(2,NULL,2,'User Guide','','2021-02-06 19:38:27','2021-02-06 19:38:27','4409bbb8-a64a-4cac-8425-6e5f34ad7983');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titleTranslationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8_unicode_ci,
  `settings` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_chigiglspybggiwfaifrqwxbmbpernxfaokl` (`name`),
  KEY `idx_zggxqjppuocnxdipsxnwjzbruxifjdilmkit` (`handle`),
  KEY `idx_mybdaczgsejbedyjldodjbdudpiavpasdkwy` (`fieldLayoutId`),
  KEY `idx_vtlofdpoqcjunpeqbrweaasbuozyolekogwm` (`dateDeleted`),
  CONSTRAINT `fk_tromyijzsxhsziyouiqqgmosemqlovwmbcif` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,1,'Uploads','uploads','craft\\volumes\\Local',1,'$ASSET_BASE_URL','site',NULL,'{\"path\":\"$ASSET_BASE_PATH\"}',1,'2021-02-06 19:34:44','2021-02-06 19:34:44',NULL,'70f5d47b-4830-4d51-95fe-bc0f7ccc0670'),(2,4,'User Guide','userGuide','craft\\volumes\\Local',1,'$GUIDE_BASE_URL','site',NULL,'{\"path\":\"$GUIDE_BASE_PATH\"}',2,'2021-02-06 19:38:27','2021-02-06 19:38:27',NULL,'d19b4314-0267-4e95-9e63-2462a334eea1');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hwwejjjjkrmingsvrrlpfoxxuowpitmifygr` (`userId`),
  CONSTRAINT `fk_gvxhzifmgtjehcexoprrponttqjxbsyolwuv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":2,\"section\":\"*\",\"limit\":10}',1,'2021-02-06 19:29:02','2021-02-06 19:29:02','4a0d7994-96c8-4557-96a3-68789dde161e'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2021-02-06 19:29:02','2021-02-06 19:29:02','fa2e0dab-7ad3-42ff-bef9-fb688584b229'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2021-02-06 19:29:02','2021-02-06 19:29:02','8d2cc063-9c90-4b90-aa96-dc35eb1ec985'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2021-02-06 19:29:02','2021-02-06 19:29:02','90cb444b-1b9b-4041-909f-c13390937ff2');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-20 18:02:38
